"""
[Blender and Python] Sending data to IDA ICE
Max Tillberg - Summer 2022
Email: max.tillberg@equa.se
--------
Copyright (c) 2022 Equa Simulation AB

Bugs:
    - Roof windows from IFC files have wrong height. Not sure why, OverallHeight seems wrong when exported. Hopefully fixed manually
    - External objects are not visible if not placed in ARCDATA and objects can only e imported oce with script
    - Zone and building bodies tends to be placed on top of each other origo

To do in IDA ICE: 
    - Make sure that zones and building bodies stays in insert position
    - That Windows imports after errors
    - Windows are imported even if they do not fit in walls
    - Greater tollerance in normal direction for windows
    - The possibility to import external shading objects twice

To do in ICE Bridge:
    - Flatten more then one object, stange bug since you need to click interface
    - Flatten Tjärlekens tak if possible
    - Adding features for DOTBIM
        - Zone names using custom object
        - New filters
    - Fast delete by using
        for ob in bpy.context.selected_objects:
            bpy.context.scene.objects.unlink(ob)
            if ob.users==0: ob.user_clear()
    - Figure out how to create zones from walls
    - Figure out how to extrude floor to roof
    - Script for simplify remove holes in floors and clean
    - Select objects with alpha or at least an instruction how to do it, involves P in edit mode
    - Center insert for windows by default before export (should be done allready??)
    - Buttons instead of drop down for common features (surprisingly hard)
    - Create rooms out of faces
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.edge_split()
        bpy.ops.mesh.separate(type='LOOSE')
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    - Add tollerance for flattening roofs
    - Possible features: Help buttons, Clear temp folder, Create zones and building bodies from floor plans, 
    - Change insert point for windows in z as mean value between max and min. Not rectangular windows will be places wrongly.
"""

bl_info = {
    # required
    'name': 'ICE Bridge',
    'blender': (3, 0, 0),
    'category': 'Object',
    # optional
    'version': (0, 8, 5),
    'author': 'Max Tillberg',
    'description': 'Export tool to IDA ICE',
}

import bpy #Used all the time
import bmesh #To clean meshes
import os #Reading and writing scripts
import mathutils 
import math
from mathutils import Matrix
from mathutils import Vector
#IFC stuff, It would be nice to check if this is available
import ifcopenshell
import blenderbim.bim.import_ifc
import blenderbim.tool as tool 
from blenderbim.bim.ifc import IfcStore 

#Function to determine largest object
def maximum(a, b):
    if a >= b:
        return a
    else:
        return b
    
from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       FloatVectorProperty,
                       EnumProperty,
                       PointerProperty,
                       )
from bpy.types import (Panel,
                       Menu,
                       Operator,
                       PropertyGroup,
                       )
#Message function for warnings
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
    def draw(self, context):
        self.layout.label(text=message)
    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------

class MyICEProperties(PropertyGroup):
   
    my_creategeometry: BoolProperty(
        name="CreateGeometry",
        description="If the exported objects should be exported as OBJ-files",
        default = False
        )
    my_shadingbool: BoolProperty(
        name="Shading",
        description="If the exported objects should shade or not",
        default = True
        )
    my_transparency: IntProperty(
        name = "Transparency",
        description="Transparency of exported external object",
        default = 0,
        min = 0,
        max = 100
        )
    my_colortransparency: IntProperty(
        name = "Transparency",
        description="Transparency of Selected Color",
        default = 0,
        min = 0,
        max = 100
        )
    my_height: FloatProperty(
        name = "Height",
        description = "Height for Move and Extrude Operations",
        default = 3, #För negativa värden, använd extude och move
        )
    my_prismaticheight: FloatProperty(
        name = "Height",
        description="Height of created zone or building body.",
        default = 3,
    ) 

    scriptfolder_path: StringProperty(
        name = "Script folder",
        description="Choose a directory to store script and geometry files in",
        default="",
        maxlen=1024,
        subtype='DIR_PATH'
        )
        
    externalobjetcsfolder_path: StringProperty(
        name = "External Objects folder",
        description="Choose a directory to store external objects",
        default="",
        maxlen=1024,
        subtype='DIR_PATH'
        )
    my_filterlist: EnumProperty(
        name="Filter Objects:",
        description="Select property to filter object by",
        items=[ ('IFCSpace', "IFCSpace", "IFCSpace", 'MOD_WIREFRAME', 0),
                ('IFCWindow', "IFCWindow", "IFCWindow", 'MOD_LATTICE', 1),
                ('IFCDoor', "IFCDoor", "IFCDoor", 'MATPLANE', 2),
                ('Glazed', "Glazed", "Glazed", 'IMAGE_DATA', 3),
                ('Glass', "Glass", "Glass", 'IMAGE_DATA', 4),
                ('Panel', "Panel", "Panel", 'VIEW_ORTHO', 5),
                ('IFCWall', "IFCWall", "IFCWall", 'MOD_BUILD', 6),
                ('IFCRoof', "IFCRoof", "IFCRoof", 'LINCURVE', 7),
                ('IFCSite', "IFCSite", "IFCSite", 'WORLD', 8),
                ('IFCSlab', "IFCSlab", "IFCSlab", 'UGLYPACKAGE', 9),
                ('IFCFurnishing', "IFCFurnishing", "IFCFurnishing", 'ASSET_MANAGER', 10),
                ('Proxy', "Proxy", "Proxy", 'QUESTION', 11),
                ('Glas as material', "Glas as material", "Glas as material", 'IMAGE_DATA', 12),
                ('@Windows', "@Windows", "Speckle Windows collection", 'MOD_LATTICE', 13),
                ('@Rooms', "@Rooms", "Speckle Rooms collection", 'MOD_WIREFRAME', 14),
                ('@Doors', "@Doors", "Speckle Doors collection", 'MATPLANE', 15),
                ('@Curtain Panels', "@Curtain Panels", "Speckle Curtain Panels collection", 'VIEW_ORTHO', 16),
                ('@Curtain Systems', "@Curtain Systems", "Speckle Curtain Systems collection", 'VIEW_ORTHO', 17),
                ('@Walls', "@Walls", "Speckle Walls collection", 'MOD_BUILD', 18),
                ('@Floors', "@Floors", "Speckle Floors collection", 'REMOVE', 19),
                ('@Grids', "@Grids", "Speckle Grids collection", 'MOD_MULTIRES', 20),
                ('@Stairs', "@Stairs", "Speckle Stairs collection", 'NLA_PUSHDOWN', 21),
                ('@Cailings', "@Ceilings", "Speckle Ceilings collection", 'NOCURVE', 22),
                ('@Railings', "@Railings", "Speckle Railings collection", 'IPO_LINEAR', 23),
                ('ICEFloors', "ICEFloors", "ICEFloors", 'REMOVE', 24),
                ('ICERoofs', "ICERoofs", "ICERoofs", 'LINCURVE', 25),
                ('ICEWindows', "ICEWindows", "ICEWindows", 'MOD_LATTICE', 26),
                ('ICEDoors', "ICEDoors", "ICEDoors", 'MATPLANE', 27),
                ('ICEBuildingBodies', "ICEBuildingBodies", "ICEBuildingBodies", 'MESH_CUBE', 28),
                ('ICEZones', "ICEZones", "ICEZones", 'MOD_WIREFRAME', 29),
                ('ICEExternalObjects', "ICEExternalObjects", "ICEExternalObjects", 'SCENE_DATA', 30),
                ('Transparent', "Transparent objects", "Transparent Objects", 'MOD_WIREFRAME', 31),
                ('WindowsCatagory', "Windows as category", "ICEExternalObjects", 'IMAGE_DATA', 32),
                ('WindowFamily', "Single Windows as family", "Wiindow as family", 'IMAGE_DATA', 33),
                ('CurtainWallFamily', "Curtain Wall as family", "Curtain Wall as family", 'VIEW_ORTHO', 34),
               ]
        )
        
    my_colorlist: EnumProperty(
        name="Color:",
        description="Color",
        items=[ ('Red', "Red", "Red"),
                ('Blue', "Blue", "Blue"),
                ('Green', "Green", "Green"),
                ('Pink', "Pink", "Pink"),
                ('Yellow', "Yellow", "Yellow"),
                ('White', "White", "White"),
                ('Orange', "Orange", "Orange"),
               ]
        )
    my_exportobjectlist: EnumProperty(
        name="Export Objects:",
        description="Choose what object type to export selected abojects as.",
        items=[ ('BuildingBodies', "Building bodies from volumes", "Volumes must be closed and made of planar surfaces. Each selected object will create one building body", 'MESH_CUBE', 0),
                ('Zones', "Zones from volumes", "Volumes must be closed and made of planar surfaces. Each selected object will create one zone", 'MOD_WIREFRAME', 1),
                ('PrismaticBuildingBodies', "Building bodies from floor planes", "Lowest points will create floor, height is determined by difference. Each selected object will create one building body", 'MESH_CUBE', 2),
                ('BuildingBodiesFromRoof', "Building bodies from roof planes", "Building body with complex roof. Each selected object will create one building body", 'MESH_CUBE', 3),
                ('PrismaticZones', "Zones from floor planes", "Each selected object will create one zone", 'MOD_WIREFRAME', 4),
                ('BuildingBodiesAndZones', "Building bodies and Zones from volumes", "Volumes must be closed and made of planar surfaces. Each selected object will create one building body and one zone", 'SNAP_VOLUME', 5),
                ('Windows', "Windows from large surfaces**", "Windows should be as planar as possible", 'MOD_LATTICE', 6),
                ('Windows2', "Windows from IFCWindows (-Y)**", "Windows without large surfaces created by IFC, probably vertical", 'MOD_LATTICE', 7),
                ('Windows3', "Windows from IFCWindows (+Z)**", "Windows without large surfaces created by IFC, probably sloping or horizontal", 'MOD_LATTICE', 8),
                ('Windows4', "Windows from bounding box", "Windows from  bounding boxes. No IFC data transfered and stray windows may be created. Warning! This script should not be run in models with zones. All imported zones will be deleted and windows will be created in excisting zones.", 'MOD_LATTICE', 9),
                ('Doors', "Doors from large surfaces**", "Doors should be as planar as possible", 'MATPLANE', 10),
                ('ExternalObjects', "External objects", "External objects can be shading and semitranparent. Group objects with similar properties.", 'SCENE_DATA', 11),
               ]
        )

    my_objectoperationlist: EnumProperty(
        name="Object operation:",
        description="Choose what operation to perform on selected objects.",
        items=[ ('CenterOfMass', "Set Origin to Center of Mass", "This is important to get midpoint of windows and doors correct", 'PIVOT_BOUNDBOX', 0),
                ('Isolate', "Isolate Selected Objects (Shift+H)", "Isolate Selected Objects", 'LIGHT_SUN', 1),
                ('Hide', "Hide Selected Objects (H)", "Hide Selected Objects", 'HIDE_ON', 2),
                ('Unhide', "Unhide Objects (Alt+H)", "Unhide Objects (Alt+H)", 'HIDE_OFF', 3),
                #('Show', "Show all Objects", "Show all Objects", 'HIDE_OFF', 3),
                ('Join', "Join Selected Objects (Ctrl+J)", "Join objects into the selected. Useful for complex building bodies, zones and external objects", 'OUTLINER_DATA_CURVE', 4),
                ('ColorObject', "Color Selected Object*", "Set Base Color and Transparency", 'COLORSET_01_VEC', 5),
                ('Duplicate', "Duplicate Selected Objects (Shift+D)", "Duplicate Selected Objects", 'DUPLICATE', 6),
                ('MoveToFilteredCollection', "Move to Filtered ICE Collection (M)", "Move to Filtered ICE Collection", 'FORWARD', 7),
                ('FlattenBottom', "Flatten Single Selected Object to Bottom*", "Flatten and Simplify Selected Objects to Lowest Selected Point. Sloping objects gets hoizontal and position is random within the object", 'ALIGN_BOTTOM', 8),
                ('FlattenMiddle', "Flatten Single Selected Object to Middle*", "Flatten and Simplify Selected Objects to Middle of Selected Points. Sloping objects gets hoizontal and position is random within the object", 'ALIGN_MIDDLE', 9),
                ('FlattenTop', "Flatten Single Selected Object to Top*", "Flatten and Simplify Selected Objects to Highest Selected Point. Sloping objects gets hoizontal and position is random within the object", 'ALIGN_TOP', 10),        
                ('ExtrudeGivenDistance', "Extrude Selected Objects Given Distance**", "Extrude Selcted Objects Given Distance Z", 'EXPORT', 11),
                ('ExtrudeToGivenZ', "Extrude Selected Objects to Given Z**", "Extrude Selcted Faces to Given Height in Z", 'IMPORT', 12),
                ('MoveGivenZ', "Move Selected Objects Given Distance in Z", "Move Selected Objects Given Distance in Z", 'SORT_DESC', 13),
                ('MoveToGivenZ', "Move Selected Objects to Given Z", "Move Selected Objects to Given Z", 'SORT_ASC', 14),
                ('RemoveGaps', "Remove Gaps between Selected Zones***", "Extend zones to center of wall", 'MOD_BOOLEAN',15),
                ('DeleteAllLow', "Delete all but Highest on Selected Objects*", "Delete all vertices exempt highest. Can be used to flatten planar objects.", 'ALIGN_TOP', 16),
                ('DeleteAllHigh', "Delete all but Lowest on Selected Objects* ", "Delete all vertices exempt lowest. Can be used to flatten planar objects.", 'ALIGN_BOTTOM', 17),        
                ('CreateCollections', "Create ICE Collection", "Create Default IDA ICE Collections.", 'COLLECTION_NEW', 18),
                ('FlattenRoof', "Flatten Complex*", "This will select all faces with a normal positive z value and delete the top vertices.", 'ALIGN_BOTTOM', 19), 
                ('Union', "Union two closed Objects", "Union two closed objects. Note that this will leave the second inacts", 'SELECT_EXTEND', 20),
                ('Intersect', "Intersection of two closed Objects", "Create the differance vlume volume of two closed objects. Note that this will leave the second inacts", 'SELECT_INTERSECT', 21), 
                ('Difference', "Remove Difference between two closed Objects", "Create the intersecting volume of two closed objects. Note that this will leave the second inacts", 'SELECT_SUBTRACT', 22),
                ('IFCStorey', "Create Planes from IFCStorey", "Create Planes at the same height at IFCStorey", 'REMOVE', 23), 
                ('SortClockwise', "Sort vertices clockwise in selected objects", "Sort vertices clockwise. Important for zones and building bodies created from planes", 'MESH_DATA', 24), 
                ('CeateBoundingBox', "Create bounding box around selected objects", "Useful for making windows", 'MOD_WIREFRAME', 25), 
               ]
        )

    my_version: EnumProperty(
        name="IDA ICE version:",
        description="Choose what IDA ICE version to export to.",
        items=[ ('ICE48', "IDA ICE 4.8 or earlier", ""),
                #('ICE50', "IDA ICE 5.0 or later", ""),
               ]
        )

# ------------------------------------------------------------------------
#    Operators /Buttons to perform actions
# ------------------------------------------------------------------------

class WM_OT_SelectFilteredObjects(Operator):
    bl_label = "Select Filtered Objects"
    bl_idname = "wm.select_filtered_objects"
    bl_description = "Add filtered objects to selection"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool

        if mytool.my_filterlist == "IFCSpace":
            bpy.ops.object.select_pattern(pattern='*IFCSpace*')
        if mytool.my_filterlist == "IFCWindow":
            bpy.ops.object.select_pattern(pattern='*IFCWindow*')
        if mytool.my_filterlist == "IFCDoor":
            bpy.ops.object.select_pattern(pattern='*IFCDoor*')
        if mytool.my_filterlist == "Glazed":
            bpy.ops.object.select_pattern(pattern='*Glazed*')
        if mytool.my_filterlist == "Glass":
            bpy.ops.object.select_pattern(pattern='*Glass*')
        if mytool.my_filterlist == "Panel":
            bpy.ops.object.select_pattern(pattern='*Panel*')
        if mytool.my_filterlist == "IFCWall":
            bpy.ops.object.select_pattern(pattern='*IFCWall*')
        if mytool.my_filterlist == "IFCRoof":
            bpy.ops.object.select_pattern(pattern='*IFCRoof*')
        if mytool.my_filterlist == "IFCSite":
            bpy.ops.object.select_pattern(pattern='*IFCSite*')
        if mytool.my_filterlist == "IFCSlab":
            bpy.ops.object.select_pattern(pattern='*IFCSlab*')
        if mytool.my_filterlist == "IFCFurnishing":
            bpy.ops.object.select_pattern(pattern='*IFCFurnishing*')
        if mytool.my_filterlist == "Proxy":
            bpy.ops.object.select_pattern(pattern='*Proxy*')
        if mytool.my_filterlist == "Glas as material":
            for obj in bpy.context.visible_objects:
                for m in obj.material_slots:
                    if "Glas" in m.name:
                        obj.select_set(True)
#                if bpy.data.objects[str(obj.name)]["category"]=="Windows":      
#                    obj.select_set(True)
        if mytool.my_filterlist == "@Windows":
            for obj in bpy.data.collections["@Windows"].all_objects:                
                obj.select_set(True)
        if mytool.my_filterlist == "@Rooms":
            for obj in bpy.data.collections["@Rooms"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Doors":
            for obj in bpy.data.collections["@Doors"].all_objects:
                obj.select_set(True) 
        if mytool.my_filterlist == "@Curtain Panels":
            for obj in bpy.data.collections["@Curtain Panels"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Curtain Systems":
            for obj in bpy.data.collections["@Curtain Systems"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Walls":
            for obj in bpy.data.collections["@Walls"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Floors":
            for obj in bpy.data.collections["@Floors"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Curtain Panels":
            for obj in bpy.data.collections["@Curtain Panels"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Grids":
            for obj in bpy.data.collections["@Grids"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Stairs":
            for obj in bpy.data.collections["@Stairs"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Ceilings":
            for obj in bpy.data.collections["@Ceilings"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Railings":
            for obj in bpy.data.collections["@Railings"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "Transparent":
            for obj in bpy.data.collections["@Railings"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "WindowsCatagory":
            for obj in bpy.context.visible_objects:
                if "category" in obj:
                    if obj["category"] == "Windows":      
                        obj.select_set(True)
        if mytool.my_filterlist == "WindowFamily":
            for obj in bpy.context.visible_objects:
                if "family" in obj:
                    if obj["family"] == "Single Windows":
                        obj.select_set(True)
        if mytool.my_filterlist == "CurtainWallFamily":
            for obj in bpy.context.visible_objects:
                if "family" in obj:
                    if obj["family"] == "Curtain Wall":  
                        obj.select_set(True)
                
        return {'FINISHED'}

class WM_OT_PerformOperation(Operator):
    bl_label = "Perform Operation"
    bl_idname = "wm.perform_operation"
    bl_description = "Perform selected operation on selected objects"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        if mytool.my_objectoperationlist == "CenterOfMass":
            selection = bpy.context.selected_objects
            for obj in selection:
               if obj.type=="MESH":
                    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
        if mytool.my_objectoperationlist == "Isolate":
            bpy.ops.object.hide_view_set(unselected=True)
        if mytool.my_objectoperationlist == "Unhide":
            bpy.ops.object.hide_view_clear()
        if mytool.my_objectoperationlist == "Hide":
            selection = bpy.context.selected_objects
            for obj in selection:
                obj.hide_set(True)              
        if mytool.my_objectoperationlist == "Join":
            selection = bpy.context.selected_objects
            obs = []
            for obj in selection:
                if obj.type == 'MESH':
                    obs.append(obj)
            ctx = bpy.context.copy()
            # one of the objects to join
            ctx['active_object'] = obs[0]
            ctx['selected_editable_objects'] = obs
            # We need the scene bases as well for joining.
            bpy.ops.object.join(ctx)

        if mytool.my_objectoperationlist == "RemoveGaps": 
            #Code from https://github.com/IfcOpenShell/IfcOpenShell/commit/eb0f2de197c94e18d6eed83e56351e1c189e07ed#diff-7a3448a810418b98f5db644b11c1bf9ad0452c88545991ecc1eda3f65c929895 
            threshold = 0.5
            processed_polygons = set()

            for obj in bpy.context.selected_objects:
                if obj.type != "MESH":
                    continue
                for polygon in obj.data.polygons:
                    center = obj.matrix_world @ polygon.center
                    distance = None
                    for obj2 in bpy.context.selected_objects:
                        if obj2 == obj or obj.type != "MESH":
                            continue
                        result = obj2.ray_cast(
                            obj2.matrix_world.inverted() @ center,
                            polygon.normal,
                            distance=threshold
                        )
                        if not result[0]:
                            continue
                        hit = obj2.matrix_world @ result[1]
                        distance = (hit - center).length / 2
                        if distance < 0.01:
                            distance = None
                            break

                        if (obj2.name, result[3]) in processed_polygons:
                            distance *= 2
                            continue

                        offset = polygon.normal * distance * -1
                        processed_polygons.add((obj2.name, result[3]))
                        for v in obj2.data.polygons[result[3]].vertices:
                            obj2.data.vertices[v].co += offset
                        break
                    if distance:
                        offset = polygon.normal * distance
                        processed_polygons.add((obj.name, polygon.index))
                        for v in polygon.vertices:
                            obj.data.vertices[v].co += offset
        if mytool.my_objectoperationlist == "CreateCollections":
            #Create standard IDA ICE collections
            if bpy.data.collections.get("ICEFloors") is None:
                collection = bpy.data.collections.new("ICEFloors")
                bpy.context.scene.collection.children.link(collection)
            if bpy.data.collections.get("ICERoofs") is None:
                collection = bpy.data.collections.new("ICERoofs")
                bpy.context.scene.collection.children.link(collection)
            if bpy.data.collections.get("ICEWindows") is None:
                collection = bpy.data.collections.new("ICEWindows")
                bpy.context.scene.collection.children.link(collection)
            if bpy.data.collections.get("ICEDoors") is None:
                collection = bpy.data.collections.new("ICEDoors")
                bpy.context.scene.collection.children.link(collection)
            if bpy.data.collections.get("ICEBuildingBodies") is None:
                collection = bpy.data.collections.new("ICEBuildingBodies")
                bpy.context.scene.collection.children.link(collection)
            if bpy.data.collections.get("ICEZones") is None:
                collection = bpy.data.collections.new("ICEZones")
                bpy.context.scene.collection.children.link(collection)
            if bpy.data.collections.get("ICEExternalObjects") is None:
                collection = bpy.data.collections.new("ICEExternalObjects")
                bpy.context.scene.collection.children.link(collection)
        if mytool.my_objectoperationlist == "ColorObject":
            transname = str(mytool.my_colortransparency/100)
            transvalue = 1 - (mytool.my_colortransparency/100)
            if str(mytool.my_colorlist) == "Red":
                tempname =  'Red' + transname
                matred = bpy.data.materials.new('Red' + transname)
                matred.diffuse_color = (1,0,0,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matred
            if str(mytool.my_colorlist) == "Blue":
                # create the material
                matblue = bpy.data.materials.new('Blue' + transname)
                matblue.diffuse_color = (0,0,1,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matblue
            if str(mytool.my_colorlist) == "Green":
                # create the material
                matgreen = bpy.data.materials.new('Green' + transname)
                matgreen.diffuse_color = (0,1,0,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matgreen
            if str(mytool.my_colorlist) == "Pink":
                # create the material
                matpink = bpy.data.materials.new('Pink' + transname)
                matpink.diffuse_color = (1,0,0.7,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matpink                
            if str(mytool.my_colorlist) == "Yellow":
                # create the material
                matyellow = bpy.data.materials.new('Yellow' + transname)
                matyellow.diffuse_color = (1,1,0,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matyellow                
            if str(mytool.my_colorlist) == "White":
                # create the material
                matwhite = bpy.data.materials.new('White' + transname)
                matwhite.diffuse_color = (1,1,1,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matwhite  
            if str(mytool.my_colorlist) == "Orange":
                # create the material
                matorange = bpy.data.materials.new('Orange' + transname)
                matorange.diffuse_color = (1,0.3,0,transvalue)
                for o in bpy.context.selected_objects:
                    # Set the active materials diffuse color to the specified RGB
                    o.active_material = matorange 
        if mytool.my_objectoperationlist == "MoveToFilteredCollection":
            print(str(mytool.my_filterlist))
            #move duplicated objects to selected Collection
            C = bpy.context
            # List of object references
            objs = C.selected_objects
            # Set target collection to a known collection 
            coll_target = C.scene.collection.children.get(str(mytool.my_filterlist))
            # If target found and object list not empty
            if coll_target and objs:
                # Loop through all objects
                for ob in objs:
                    # Loop through all collections the obj is linked to
                    for coll in ob.users_collection:
                        # Unlink the object
                        coll.objects.unlink(ob)
                    # Link each object to the target collection
                    coll_target.objects.link(ob)
        if mytool.my_objectoperationlist == "Duplicate":
            #Duplicate selected objects
            bpy.ops.object.duplicate()
            dupli_obj = bpy.context.object
        if mytool.my_objectoperationlist == "DeleteAllHigh" or mytool.my_objectoperationlist == "DeleteAllLow":
            C = bpy.context
            objs = C.selected_objects
            for ob in objs:
                print(ob.name)
                msh = bmesh.new()
                msh.from_mesh( ob.data )  # access the object mesh data
                msh.verts.ensure_lookup_table() # for coherency
                loc_vertex_coordinates = [ v.co for v in msh.verts ] # local coordinates of vertices
                # Find the lowest Z value amongst the object's verts
                minZ = min( [ co.z for co in loc_vertex_coordinates ] ) 
                maxZ = max( [ co.z for co in loc_vertex_coordinates ] )
                # Delete all vertices below maxZ (or above low)
                for v in msh.verts:
                    if mytool.my_objectoperationlist == "DeleteAllHigh":
                        if v.co.z > minZ:
                            print('remove',v,'at',v.co)
                            msh.verts.remove(v)
                    if mytool.my_objectoperationlist == "DeleteAllLow":
                        if v.co.z < maxZ:
                            print('remove',v,'at',v.co)
                            msh.verts.remove(v)
                msh.to_mesh(ob.data) # write the bmesh back to the mesh
                msh.free()  # free and prevent further access
                #Clean up
#                bpy.ops.mesh.delete(type='VERT')
#                bpy.ops.mesh.remove_doubles()
#                bpy.ops.mesh.dissolve_degenerate() #Clean som more
#                bpy.ops.mesh.edge_face_add() #Merge
        if mytool.my_objectoperationlist == "FlattenBottom" or mytool.my_objectoperationlist == "FlattenMiddle" or mytool.my_objectoperationlist == "FlattenTop":
            C = bpy.context
            objs = C.selected_objects
            for ob in objs:
                #mw = ob.matrix_world # Active object's world matrix
                loc_vertex_coordinates = [ v.co for v in ob.data.vertices ] # local coordinates of vertices
                # Find the lowest Z value amongst the object's verts
                minZ = min( [ co.z for co in loc_vertex_coordinates ] ) 
                maxZ = max( [ co.z for co in loc_vertex_coordinates ] )
                meanZ = (minZ + maxZ)/2
                if mytool.my_objectoperationlist == "FlattenBottom":
                    # Set Z for all vertices
                    for v in ob.data.vertices:
                        v.co.z = minZ
                if mytool.my_objectoperationlist == "FlattenMiddle":
                    # Set Z for all vertices
                    for v in ob.data.vertices:
                        v.co.z = meanZ
                if mytool.my_objectoperationlist == "FlattenTop":
                    # Set Z for all vertices
                    for v in ob.data.vertices:
                        v.co.z = maxZ
                if mytool.my_objectoperationlist == "FlattenBottom" or mytool.my_objectoperationlist == "FlattenMiddle" or mytool.my_objectoperationlist == "FlattenTop":
                    #Clean
                    if bpy.context.selected_objects != []:
                        if ob.type == 'MESH':
                            bpy.context.view_layer.objects.active = ob # obj is the active object now
                            bpy.ops.object.editmode_toggle()
                            bpy.ops.mesh.select_all(action='SELECT')
                            bpy.ops.mesh.remove_doubles()
                            bpy.ops.mesh.dissolve_degenerate() #Clean som more
                            bpy.ops.mesh.edge_face_add() #Merge
                            bpy.ops.object.editmode_toggle()
        if mytool.my_objectoperationlist == "ExtrudeGivenDistance":
            #Two alternative methods, move and solidify. Move edit out since it doeas not work very well
            bpy.ops.object.mode_set( mode   = 'EDIT'   )
            bpy.ops.mesh.select_mode( type  = 'FACE'   )
            bpy.ops.mesh.extrude_region_move(
                TRANSFORM_OT_translate={"value":(0, 0, mytool.my_height)} #Extrude in Z. 
            )
            bpy.ops.object.editmode_toggle()

#            bpy.ops.object.modifier_add(type='SOLIDIFY')
#            bpy.context.object.modifiers["Solidify"].thickness = mytool.my_height
#            bpy.context.object.modifiers["Solidify"].offset = 1
#            bpy.ops.object.modifier_apply(modifier="Solidify")


        if mytool.my_objectoperationlist == "ExtrudeToGivenZ":
            ob = bpy.context.object
            ob.update_from_editmode()
            me = ob.data
            verts_sel = [v.co for v in me.vertices if v.select]
            pivot = sum(verts_sel, Vector()) / len(verts_sel)

            #print("Local:", pivot)
            Global = ob.matrix_world @ pivot
            #print("Global:", Global[2])
            
            bpy.ops.object.mode_set( mode   = 'EDIT'   )
            bpy.ops.mesh.select_mode( type  = 'FACE'   )
            bpy.ops.mesh.extrude_region_move(
                TRANSFORM_OT_translate={"value":(0, 0, Global[2] + mytool.my_height)} #Extrude in Z. 
            )
            bpy.ops.object.editmode_toggle()  

        if mytool.my_objectoperationlist == "MoveToGivenZ":
            obj = bpy.context.object
            # get the minimum z-value of all vertices after converting to global transform
            #lowest_pt = min([(obj.matrix_world @ v.co).z for v in obj.data.vertices])
            # transform the object
            obj.location.z = mytool.my_height
        if mytool.my_objectoperationlist == "MoveGivenZ":
            bpy.ops.transform.translate(value=(-0, -0, mytool.my_height), orient_axis_ortho='X', orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(False, False, True), mirror=False, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False, release_confirm=True)

        if mytool.my_objectoperationlist == "Union" or mytool.my_objectoperationlist == "Difference" or mytool.my_objectoperationlist == "Intersect":
            # initialize the variables to work with, in this case two selected objects, in yours c1mesh and c2mesh
            first_object = bpy.context.selected_objects[0]
            second_object = bpy.context.selected_objects[1]

            # add the modifier and change settings
            first_object.modifiers.new(name = "Boolean", type = 'BOOLEAN')
            if mytool.my_objectoperationlist == "Union":
                first_object.modifiers.get("Boolean").operation = "UNION"
            if mytool.my_objectoperationlist == "Difference":
                first_object.modifiers.get("Boolean").operation = "DIFFERENCE"
            if mytool.my_objectoperationlist == "Intersect":
                first_object.modifiers.get("Boolean").operation = "INTERSECT"
            first_object.modifiers.get("Boolean").object = second_object

            # just cosmetic hiding of second object so you can instantly see the result
            second_object.hide_viewport = True
            
        if mytool.my_objectoperationlist == "IFCStorey":
            #Create store from IFC https://community.osarch.org/discussion/1047/blenderbim-create-faces-for-ifcbuildingstorey#latest
            ifc_file = ifcopenshell.open(IfcStore.path)
            products = ifc_file.by_type('IfcProduct')
            for ifcproduct in products:
                if ifcproduct:
                    if ifcproduct.is_a() == "IfcBuildingStorey":
                        x = (ifcproduct.ObjectPlacement.RelativePlacement.Location.Coordinates[0])
                        y = (ifcproduct.ObjectPlacement.RelativePlacement.Location.Coordinates[1])
                        z = (ifcproduct.ObjectPlacement.RelativePlacement.Location.Coordinates[2])
                        #print (x, y, z, ifcproduct.Elevation)
                        #print (ifcproduct.ObjectPlacement)
                        bpy.ops.mesh.primitive_plane_add(size=100, enter_editmode=False, align='WORLD', location=(x, y, (ifcproduct.Elevation)/1000), scale=(1, 1, 1))
                        bpy.context.active_object.name = str(ifcproduct.Name)
                        bpy.ops.bim.assign_class(ifc_class="IfcBuildingElementProxy", predefined_type="", userdefined_type="")
        
        if mytool.my_objectoperationlist == "SortClockwise":
            #This is a highly destructive operation that converts meshes to curves and back again. All faces will be lost
            bpy.ops.object.convert(target='CURVE', keep_original= False)
            bpy.ops.object.convert(target='MESH', keep_original= False)
            context = bpy.context
            distance = 0.01 # remove doubles tolerance.
            if True: #def execute(self, context):
                meshes = set(o.data for o in context.selected_objects
                                  if o.type == 'MESH')
                bm = bmesh.new()
                for m in meshes:
                    bm.from_mesh(m)
                    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=distance)
                    bm.to_mesh(m)
                    m.update()
                    bm.clear()
                bm.free()
            #Run this once again
            bpy.ops.object.convert(target='CURVE', keep_original= False)
            bpy.ops.object.convert(target='MESH', keep_original= False)
        if mytool.my_objectoperationlist == "CeateBoundingBox":
            selected = bpy.context.selected_objects
            for obj in selected:
                #ensure origin is centered on bounding box center
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
                #create a cube for the bounding box
                bpy.ops.mesh.primitive_cube_add() 
                #our new cube is now the active object, so we can keep track of it in a variable:
                bound_box = bpy.context.active_object 
                #copy transforms
                bound_box.dimensions = obj.dimensions
                bound_box.location = obj.location
                bound_box.rotation_euler = obj.rotation_euler
        if mytool.my_objectoperationlist == "FlattenRoof":
            #Faltten roof, rather complex model, https://blender.stackexchange.com/questions/269822/flatten-roofs-into-inner-ceiling

            NORMAL_Z_THRESHOLD = 0.1
            MERGE_BY_DISTANCE_THRESHOLD = 0.025

            objects = bpy.context.view_layer.objects
            selected_objects = bpy.context.selected_objects

            if not objects.active.select_get() and len(selected_objects) > 0:
                objects.active = selected_objects[0]

            # ========================================================================================
            #
            # Starting in 3.2 context overrides are deprecated in favor of temp_override
            # https://docs.blender.org/api/3.2/bpy.types.Context.html#bpy.types.Context.temp_override
            #
            # They are scheduled to be removed in 3.3
            #
            # ========================================================================================

            def use_temp_override():
                ''' Determine whether Blender is 3.2 or newer and requires
                    the temp_override function, or is older and requires
                    the context override dictionary
                '''
                version = bpy.app.version
                major = version[0]
                minor = version[1]

                return not (major < 3 or (major == 3 and minor < 2))

            win = bpy.context.window
            scr = win.screen

            def get_areas(type):
                return [area for area in scr.areas if area.type == type]

            def get_regions(areas):
                return [region for region in areas[0].regions if region.type == 'WINDOW']

            def select_outer_edges():
                o = bpy.context.edit_object
                m = o.data
                bm = bmesh.from_edit_mesh(m)
                bm.select_mode |= {'EDGE'}
                for e in bm.edges:
                    e.select = e.is_boundary
                bm.select_flush_mode()
                m.update()

            def unselect_isolated_faces(bm):
                bm = bmesh.from_edit_mesh(o.data)

                for face in bm.faces:
                    if not face.select:
                        continue
                    no_selected_adj_faces = True
                    for e in face.edges:
                        for f in e.link_faces:
                            if not f is face:
                                no_selected_adj_faces = no_selected_adj_faces and not f.select

                    face.select = not no_selected_adj_faces

            def select_top_faces(o):
                bm = bmesh.from_edit_mesh(o.data)
                t = NORMAL_Z_THRESHOLD
                face_indices = []

                for f in bm.faces:
                    f.select = f.normal.z > t and ((f.normal.x + f.normal.y)*0.5 < 0)

                unselect_isolated_faces(bm)
                
                face_indices = [f.index for f in bm.faces if f.select]

                for f in bm.faces:
                    f.select = False

                for f in bm.faces:
                    f.select = f.index in face_indices

                for f in bm.faces:
                    f.select = f.normal.z > t and (-(f.normal.x + f.normal.y)*0.5 < 0)

                unselect_isolated_faces(bm)

                for f in bm.faces:
                    if f.index in face_indices:
                        f.select = True

            def process_object(o):

                areas  = get_areas('VIEW_3D')

                # ========================================================================================
                # (if) execute using temp override
                # ========================================================================================

                if use_temp_override():

                    with bpy.context.temp_override(window=win, area=areas[0], regions=get_regions(areas)[0], screen=scr):

                        bpy.ops.object.select_all(action='DESELECT')

                        o.select_set(True)
                        bpy.context.view_layer.objects.active = o

                        bpy.ops.object.editmode_toggle()
                        bpy.ops.mesh.select_all(action='SELECT')
                        bpy.ops.mesh.remove_doubles(threshold=MERGE_BY_DISTANCE_THRESHOLD)
                        bpy.ops.mesh.select_all(action='DESELECT')

                        select_top_faces(o)

                        bpy.ops.mesh.delete(type='VERT')
                        bpy.ops.mesh.select_all(action='SELECT')
                        bpy.ops.mesh.normals_make_consistent(inside=False)
                        bpy.ops.mesh.select_mode(type="EDGE")

                        select_outer_edges()

                        bpy.ops.mesh.select_mode(type="VERT")
                        bpy.ops.mesh.select_all(action='INVERT')
                        bpy.ops.mesh.dissolve_verts()
                        bpy.ops.object.editmode_toggle()

                # ========================================================================================
                # (else) execute using legacy override
                # ========================================================================================        

                else:
                    override = {
                        'window': win,
                        'screen': scr,
                        'area': areas[0],
                        'region': get_regions(areas)[0],
                    }

                    bpy.ops.object.select_all(override, action='DESELECT')
                    
                    o.select_set(True)
                    bpy.context.view_layer.objects.active = o

                    bpy.ops.object.editmode_toggle(override)
                    bpy.ops.mesh.select_all(override, action='SELECT')
                    bpy.ops.mesh.remove_doubles(override, threshold=MERGE_BY_DISTANCE_THRESHOLD)
                    bpy.ops.mesh.select_all(override, action='DESELECT')

                    select_top_faces(o)

                    bpy.ops.mesh.delete(override, type='VERT')
                    bpy.ops.mesh.select_all(override, action='SELECT')
                    bpy.ops.mesh.normals_make_consistent(override, inside=False)
                    bpy.ops.mesh.select_mode(override, type="EDGE")

                    select_outer_edges()

                    bpy.ops.mesh.select_mode(override, type="VERT")
                    bpy.ops.mesh.select_all(override, action='INVERT')
                    bpy.ops.mesh.dissolve_verts(override)
                    bpy.ops.object.editmode_toggle(override)

            # ========================================================================================
            # execute script
            # ========================================================================================

            list = [o for o in selected_objects]

            for o in list:
                if not o.type == 'MESH':
                    continue

                process_object(o)

            for o in list:
                o.select_set(True)
            

        return {'FINISHED'}

class WM_OT_Export(Operator):
    bl_label = "Export to IDA ICE"
    bl_idname = "wm.ice_export_script"
    bl_description = "Export selected objects as IDA ICE objects to selected script folder"

    def execute(self, context):
        ifc_data = IfcStore.get_file()
        scene = context.scene
        mytool = scene.my_tool
        #Use fixed script names based upon object type
        if mytool.my_exportobjectlist == "BuildingBodies":
            scriptname = "ImportBuildingBodies.txt"
        if mytool.my_exportobjectlist == "Zones":
            scriptname = "ImportZones.txt"
        if mytool.my_exportobjectlist == "PrismaticBuildingBodies":
            scriptname = "ImportBuildingBodies.txt"
        if mytool.my_exportobjectlist == "PrismaticZones":
            scriptname = "ImportZones.txt"
        if mytool.my_exportobjectlist == "BuildingBodiesFromRoof":
            scriptname = "ImportBuildingBodies.txt"
        if mytool.my_exportobjectlist == "BuildingBodiesAndZones":
            scriptname = "ImportBuildingBodiesAndZones.txt"
        if mytool.my_exportobjectlist == "Windows":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Windows2":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Windows3":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Windows4":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Doors":
            scriptname = "ImportDoors.txt"
        if mytool.my_exportobjectlist == "ExternalObjects":
            scriptname = "ImportExternalObjects.txt"
        #Open a script file to write to, make sure that there are a path selected
        if mytool.scriptfolder_path == "":
            ShowMessageBox("Script folder path is missing", "Warning", 'ERROR')
            return {'FINISHED'}
        if mytool.externalobjetcsfolder_path == "" and mytool.my_exportobjectlist == "ExternalObjects":
            ShowMessageBox("External objects folder path is missing", "Warning", 'ERROR')
            return {'FINISHED'}
            #ShowMessageBox("Script folder path is missing")
            #ShowMessageBox("This is a message", "This is a custom title")
        ICEScript=open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname,'w')
        
        if mytool.my_exportobjectlist == "PrismaticBuildingBodies" or mytool.my_exportobjectlist == "PrismaticZones":
            ICEScript.write('(:UPDATE [@]' +'\n')
           #Create zones or building bodies based upon a series of points at lowest
            C = bpy.context
            objs = C.selected_objects
            for ob in objs:
                #Get Speckle category, type and family
                #Check if a name exists. We should also check if name is valid and unique
                custompropertyexists = bpy.data.objects[str(ob.name)].get('name') is not None
                if custompropertyexists == True:
                    fn = (str(bpy.data.objects[str(ob.name)]['number'])) + " " +(str(bpy.data.objects[str(ob.name)]['name']))
                elif custompropertyexists == False:
                    fn = str(ob.name)
                print(fn)
                #Replace long Speckle names
                fn = fn.replace("Objects.Geometry.Mesh -- ", "")
                fn = fn.replace('/', '_') #IFC-names can be invalid file names
                fn = fn.replace(':', '_') #IFC-names can be invalid file names
                fn = fn.replace('.', '_') #IFC-names can be invalid file names
                print (fn)
                if mytool.my_exportobjectlist == "PrismaticZones":
                    ICEScript.write('(:ADD (CE-ZONE :N "')
                    ICEScript.write(fn)
                if mytool.my_exportobjectlist == "PrismaticBuildingBodies":
                    ICEScript.write('(:ADD (CE-SECTION :N "')
                    ICEScript.write(fn + "bb") #Add bb to name to avoid colliding names
                if mytool.my_exportobjectlist == "PrismaticZones":
                    ICEScript.write('" :T ZONE)' +'\n')
                if mytool.my_exportobjectlist == "PrismaticBuildingBodies":
                    ICEScript.write('" :T BUILDING-SECTION)' +'\n')
                if mytool.my_exportobjectlist == "PrismaticZones":
                    ICEScript.write('((AGGREGATE :N GEOMETRY :X ZONE)' +'\n')
                    ICEScript.write("(:PAR :N ORIGIN :V #(0.0 0.0) :S '(:DEFAULT NIL 2))" +'\n')
                ICEScript.write('(:PAR :N NCORN :V ')
                mw = ob.matrix_world # Active object's world matrix
                #loc_vertex_coordinates = [ v.co for v in ob.data.vertices ] # local coordinates of vertices
                glob_vertex_coordinates = [ mw @ v.co for v in ob.data.vertices ] # Global coordinates of vertices
                # Find the lowest Z and higest value amongst the object's verts
                minZ = min( [ co.z for co in glob_vertex_coordinates  ] ) 
                maxZ = max( [ co.z for co in glob_vertex_coordinates  ] )
                #ceilingheight = maxZ - minZ
                ceilingheight = mytool.my_prismaticheight
                #determine how many points there are, right now this is quite crude and I make the same check twice
                temppoints = 0
                for v in ob.data.vertices:
                    if (mw @ v.co).z == minZ:
                        temppoints = temppoints + 1
                ICEScript.write(str(temppoints))
                ICEScript.write(" :S '(:DEFAULT NIL 2))" +'\n')
                if mytool.my_exportobjectlist == "PrismaticZones":
                    #ICEScript.write("(:PAR :N HEIGHT-TO-ROOF :V :TRUE)" +'\n')
                    ICEScript.write("(:PAR :N CEILING-HEIGHT :V ")
                    ICEScript.write(str(ceilingheight))
                    ICEScript.write(")" +'\n')
                    ICEScript.write("(:PAR :N FLOOR_HEIGHT_FROM_GROUND :V ")
                    ICEScript.write(str(minZ))
                    ICEScript.write(")" +'\n')
                ICEScript.write("(:PAR :N CORNERS :DIM (")
                ICEScript.write(str(temppoints))
                ICEScript.write(" 2) :V #2A(")
                bpy.ops.object.editmode_toggle()
                for v in ob.data.vertices:
                    if (mw @ v.co).z == minZ:
                        ICEScript.write("(")
                        #ICEScript.write(" " + str(v.index) + " ")
                        ICEScript.write(str(-1*(mw @ v.co).x))
                        ICEScript.write(" ")
                        ICEScript.write(str(-1*(mw @ v.co).y))
                        ICEScript.write(") ")
                if mytool.my_exportobjectlist == "PrismaticZones":
                    ICEScript.write("))))" +'\n')
                if mytool.my_exportobjectlist == "PrismaticBuildingBodies":
                    ICEScript.write("))" +'\n')
                    ICEScript.write("(:PAR :N HEIGHT :V ")
                    ICEScript.write(str(minZ + ceilingheight))
                    ICEScript.write(")" +'\n')
                    ICEScript.write("(:PAR :N BOTTOM :V ")
                    ICEScript.write(str(minZ))
                    ICEScript.write("))" +'\n')
                bpy.ops.object.editmode_toggle()
            ICEScript.write(")" +'\n')
            ICEScript.close()
            #Replace  \ with \\
            # Read in the file
            with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'r') as file :
              filedata = file.read()

            # Replace the target string
            filedata = filedata.replace("\\", "\\\\")

            # Write the file out again
            with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'w') as file:
              file.write(filedata)

            return {'FINISHED'}

        if mytool.my_exportobjectlist == "BuildingBodiesFromRoof":
            ICEScript.write('(:UPDATE [@]' +'\n')
           #Create building bodies based upon a series of points describing roof. Floor is at given absoute height
            C = bpy.context
            objs = C.selected_objects
            for ob in objs:
                #Write the script
                ICEScript.write('(:ADD (CE-SECTION :N "')
                ICEScript.write(str(ob.name))
                ICEScript.write('" :T BUILDING-SECTION :D "Building body")' +'\n')
                ICEScript.write('(:PAR :N NCORN :V ')
                mw = ob.matrix_world # Active object's world matrix
                glob_vertex_coordinates = [ mw @ v.co for v in ob.data.vertices ] # Global coordinates of vertices
                #determine how many points there are, right now this is quite crude and I make the same check twice
                temppoints = 0
                for v in ob.data.vertices:
                    temppoints = temppoints + 1
                ICEScript.write(str(temppoints))
                ICEScript.write(')' +'\n')
                ICEScript.write('(:PAR :N CORNERS :DIM (' + str(temppoints) +' 2) :V #2A(')
                for v in reversed(ob.data.vertices):
                    ICEScript.write("(")
                    ICEScript.write(str(-1*(mw @ v.co).x))
                    ICEScript.write(" ")
                    ICEScript.write(str(-1*(mw @ v.co).y))
                    ICEScript.write(") ")
                ICEScript.write("))" +'\n')
                ICEScript.write('((FACE :N "Crawl space" :T CRAWL-FACE :INDEX -2000)' +'\n')
                ICEScript.write('(:PAR :N NCORN :V 0)' +'\n')
                ICEScript.write('(:PAR :N CORNERS :DIM (0 3) :V #2A())' +'\n')
                ICEScript.write('((FACE :N GROUND-FACE)' +'\n')
                ICEScript.write('(:PAR :N NCORN :V ' + str(temppoints) + ")" +'\n')
                ICEScript.write('(:PAR :N CORNERS :DIM (' + str(temppoints) +' 3) :V #2A(')
                for v in reversed(ob.data.vertices):
                    ICEScript.write("(")
                    ICEScript.write(str(-1*(mw @ v.co).x))
                    ICEScript.write(" ")
                    ICEScript.write(str(-1*(mw @ v.co).y))
                    ICEScript.write(" ")
                    ICEScript.write(str(mytool.my_prismaticheight)) #Here the height is the z0 for the building body
                    ICEScript.write(") ")
                ICEScript.write("))))" +'\n')
                ICEScript.write('((ROOF-FACE :N "Roof" :T ROOF-FACE :INDEX -1000)' +'\n')
                ICEScript.write("(:PAR :N NCORN :V " + str(temppoints)+ ")" +'\n')
                ICEScript.write("(:PAR :N CORNERS :DIM (" + str(temppoints) + " 3) :V #2A(")
                for v in ob.data.vertices: #I guess the height needs to be reversed since in is defined from the inside
                    ICEScript.write("(")
                    ICEScript.write(str(-1*(mw @ v.co).x))
                    ICEScript.write(" ")
                    ICEScript.write(str(-1*(mw @ v.co).y))
                    ICEScript.write(" ")
                    ICEScript.write(str((mw @ v.co).z))
                    ICEScript.write(") ")
                ICEScript.write("))))" +'\n')
                #Write the inverted script
                ICEScript.write('(:ADD (CE-SECTION :N "')
                ICEScript.write(str(ob.name) +"inv")
                ICEScript.write('" :T BUILDING-SECTION :D "Building body")' +'\n')
                ICEScript.write('(:PAR :N NCORN :V ')
                mw = ob.matrix_world # Active object's world matrix
                glob_vertex_coordinates = [ mw @ v.co for v in ob.data.vertices ] # Global coordinates of vertices
                #determine how many points there are, right now this is quite crude and I make the same check twice
                temppoints = 0
                for v in ob.data.vertices:
                    temppoints = temppoints + 1
                ICEScript.write(str(temppoints))
                ICEScript.write(')' +'\n')
                ICEScript.write('(:PAR :N CORNERS :DIM (' + str(temppoints) +' 2) :V #2A(')
                for v in ob.data.vertices:
                    ICEScript.write("(")
                    ICEScript.write(str(-1*(mw @ v.co).x))
                    ICEScript.write(" ")
                    ICEScript.write(str(-1*(mw @ v.co).y))
                    ICEScript.write(") ")
                ICEScript.write("))" +'\n')
                ICEScript.write('((FACE :N "Crawl space" :T CRAWL-FACE :INDEX -2000)' +'\n')
                ICEScript.write('(:PAR :N NCORN :V 0)' +'\n')
                ICEScript.write('(:PAR :N CORNERS :DIM (0 3) :V #2A())' +'\n')
                ICEScript.write('((FACE :N GROUND-FACE)' +'\n')
                ICEScript.write('(:PAR :N NCORN :V ' + str(temppoints) + ")" +'\n')
                ICEScript.write('(:PAR :N CORNERS :DIM (' + str(temppoints) +' 3) :V #2A(')
                for v in ob.data.vertices:
                    ICEScript.write("(")
                    ICEScript.write(str(-1*(mw @ v.co).x))
                    ICEScript.write(" ")
                    ICEScript.write(str(-1*(mw @ v.co).y))
                    ICEScript.write(" ")
                    ICEScript.write(str(mytool.my_prismaticheight)) #Here the height is the z0 for the building body
                    ICEScript.write(") ")
                ICEScript.write("))))" +'\n')
                ICEScript.write('((ROOF-FACE :N "Roof" :T ROOF-FACE :INDEX -1000)' +'\n')
                ICEScript.write("(:PAR :N NCORN :V " + str(temppoints)+ ")" +'\n')
                ICEScript.write("(:PAR :N CORNERS :DIM (" + str(temppoints) + " 3) :V #2A(")
                for v in reversed(ob.data.vertices): #I guess the height needs to be reversed since in is defined from the inside
                    ICEScript.write("(")
                    ICEScript.write(str(-1*(mw @ v.co).x))
                    ICEScript.write(" ")
                    ICEScript.write(str(-1*(mw @ v.co).y))
                    ICEScript.write(" ")
                    ICEScript.write(str((mw @ v.co).z))
                    ICEScript.write(") ")
                ICEScript.write("))))" +'\n')
            ICEScript.write(")" +'\n')
            ICEScript.close()
            #Replace  \ with \\
            # Read in the file
            with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'r') as file :
              filedata = file.read()

            # Replace the target string
            filedata = filedata.replace("\\", "\\\\")

            # Write the file out again
            with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'w') as file:
              file.write(filedata)
            return {'FINISHED'}

        #Divide the code in two parts, scripts that exports geometries and scripts that does not
        if mytool.my_exportobjectlist == "BuildingBodies" or mytool.my_exportobjectlist == "Zones" or mytool.my_exportobjectlist == "BuildingBodiesAndZones" or mytool.my_exportobjectlist == "ExternalObjects" or mytool.my_exportobjectlist == "Windows4":
            if mytool.my_exportobjectlist == "ExternalObjects" or mytool.my_creategeometry == True: 
                view_layer = bpy.context.view_layer
                obj_active = view_layer.objects.active
                selection = bpy.context.selected_objects
                bpy.ops.object.select_all(action='DESELECT')
                if mytool.my_exportobjectlist == "ExternalObjects":
                    ICEScript.write('(:UPDATE [@]' +'\n')
                    ICEScript.write('(:ADD (AGGREGATE :N ARCDATA)' + '\n')

                for obj in selection:
                    obj.select_set(True)
                    #Get Speckle category, type and family
                    #Check if a name exists. We should also check if name is valid and unique
                    custompropertyexists = bpy.data.objects[str(obj.name)].get('name') is not None
                    if custompropertyexists == True:
                            fn = (str(bpy.data.objects[str(obj.name)]['number'])) + " " +(str(bpy.data.objects[str(obj.name)]['name']))
                    elif custompropertyexists == False:
                        fn = str(obj.name)
                    #Replace long Speckle names
                    fn = fn.replace("Objects.Geometry.Mesh -- ", "")
                    fn = fn.replace('/', '_') #IFC-names can be invalid file names
                    fn = fn.replace(':', '_') #IFC-names can be invalid file names
                    fn = fn.replace('.', '_') #IFC-names can be invalid file names
                    if mytool.my_exportobjectlist == "BuildingBodies":
                        fn = fn + "bb"
                    fnorg = fn #save the zone name for later
                    fn = (str(bpy.path.abspath(mytool.scriptfolder_path)) + str(fn)) #Get path
                    shadename = (str(bpy.path.abspath(mytool.externalobjetcsfolder_path)) + str(fnorg)) #Get path
                    #Exported location for obj-files should be places in tempfolder with the exception of shading objects that are permanent
                    if mytool.my_exportobjectlist == "ExternalObjects":
                        fp = shadename  + '.obj'
                    else:
                        fp = fn  + '.obj'
                    #some exporters only use the active object
                    view_layer.objects.active = obj
                    bpy.ops.export_scene.obj(filepath=fp, axis_forward='-Y', axis_up='Z', use_selection=True, check_existing=True)
                    #The actual script varies with object type
                    if mytool.my_exportobjectlist == "BuildingBodies":
                        ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'building-body ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n')
                    if mytool.my_exportobjectlist == "Zones":
                        ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'zone ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n' + '(:REMOVE "' + str(fnorg) + '-s")'+'\n')
                    if mytool.my_exportobjectlist == "BuildingBodiesAndZones":
                        ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'zone ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n')
                    if mytool.my_exportobjectlist == "ExternalObjects":
                        ICEScript.write('((AGGREGATE :N "' + fnorg + '" :T PICT3D)(:PAR :N FILE :V "' + fp + '")(:PAR :N TRANSPARENCY :V ' + str(mytool.my_transparency) + ')(:PAR :N SHADOWING :V :' + str(mytool.my_shadingbool) + '))' +'\n')
                    if mytool.my_exportobjectlist == "Windows4":
                         ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'zone ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n' + '(:REMOVE "' + str(fnorg) + '-s")'+'\n')
                    obj.select_set(False)
                if mytool.my_exportobjectlist == "ExternalObjects":
                    ICEScript.write('))')
                if mytool.my_exportobjectlist == "Windows4":
                    #Create temp zones, 100% windows, move windows to building and delete temp zones
                    #To avoid stray windows in roofs no horizontal windows are created
                    ICEScript.write('(:for (w [@ :ice-all-enclosing] :when (<= 90 [w geometry slope] 179) ) (add-band-feature w 1 0 window) )' +'\n' + "(:call mapcar 'zone-windows-to-face [@ :zones])" +'\n' + '(:for (zone_ [@ :zones] :when (:call string-equal "direct-import" [zone_ group])) (:call delete-component zone_))')

                ICEScript.close()
                view_layer.objects.active = obj_active

                for obj in selection:
                    obj.select_set(True)

                #Replace  \ with \\
                # Read in the file
                with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'r') as file :
                  filedata = file.read()

                # Replace the target string
                filedata = filedata.replace("\\", "\\\\")

                # Write the file out again
                with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'w') as file:
                  file.write(filedata)

                return {'FINISHED'}
            elif mytool.my_creategeometry == False:
                C = bpy.context
                objs = C.selected_objects
                for ob in objs:
                    #me = bpy.context.object.data
                    me = ob.data
                    # per-poly lists of loop indices
                    pli = (p.loop_indices for p in me.polygons)
                    # .. to per-poly lists of vertex indices
                    pvi = ([me.loops[l].vertex_index for l in ll] for ll in pli)
                    # ..to per-poly lists of vertices
                    p_verts = ([me.vertices[id] for id in idl] for idl in pvi)
                    # floating point precision
                    prec = 2
                    co_lists =[]
                    
                    for v_list in p_verts:
                        co_str = '('
                        co_strs = []
                        for v in [*v_list[::-1],v_list[-1]]:
                            tempx = (-1*v.co[0])
                            tempy = (-1*v.co[1])
                            co_strs.append(f'{tempx: .{prec}f} '
                                           f'{tempy: .{prec}f} '
                                           f'{v.co[2]: .{prec}f}')
                        co_str += ') ('.join(co_strs)
                        co_str += ')'
                        co_lists.append(co_str)
                    DBstr =  "(:set building [@])\n"
                    DBstr +=  "(:set pset (:call polyhedron-p '(("  
                    DBstr += ") (".join(co_lists)
                    DBstr += "))))\n"
                    DBstr += "(:set ((bsect zone) (:call values-output-as-list 'surfaces-to-zone nil '(0 0 0) 'ce-zone 'zone :pset pset)))\n"
                    #Get Speckle category, type and family
                    #Check if a name exists. We should also check if name is valid and unique
                    custompropertyexists = bpy.data.objects[str(ob.name)].get('name') is not None
                    if custompropertyexists == True:
                            fn = (str(bpy.data.objects[str(ob.name)]['number'])) + " " +(str(bpy.data.objects[str(ob.name)]['name']))
                    elif custompropertyexists == False:
                        fn = str(ob.name)
                    #Replace long Speckle names
                    fn = fn.replace("Objects.Geometry.Mesh -- ", "")
                    fn = fn.replace('/', '_') #IFC-names can be invalid file names
                    fn = fn.replace(':', '_') #IFC-names can be invalid file names
                    fn = fn.replace('.', '_') #IFC-names can be invalid file names
                    DBstr += '(:call Lform-Set-Attributes zone :n "'  + fn + '")\n'
                    DBstr += '(:call Lform-Set-Attributes bsect :n "'  + fn + 'bb")\n'
                    if mytool.my_exportobjectlist == "Zones" or mytool.my_exportobjectlist == "BuildingBodiesAndZones":
                        DBstr += "(:set zone (:call create-and-add-component building zone nil))\n"
                    if mytool.my_exportobjectlist == "BuildingBodies" or mytool.my_exportobjectlist == "BuildingBodiesAndZones":
                        DBstr += "(:set bsect (:call create-and-add-component building bsect nil))\n"
                    ICEScript.write(str(DBstr))
                return {'FINISHED'}
        #Code for exporting windows and doors
        if mytool.my_exportobjectlist == "Windows" or mytool.my_exportobjectlist == "Windows2" or mytool.my_exportobjectlist == "Windows3" or mytool.my_exportobjectlist == "Doors":
            from bpy import context as C
            for ob in C.selected_objects:
                mw = ob.matrix_world #Normal direction should be according to world
                N = mw.inverted_safe().transposed().to_3x3() #Normal direction should be according to world
                #Make sure only meshes are selected
                if ob.type=='MESH': #Ensure origin is centered on bounding box center
                    if bpy.ops.object.type=='MESH':
                        bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
                        #Center origin
                        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
                    centre = ob.location  # Does this work for all objects? All objects should be changed mnually manually by using Object-Set Origin-Origin to center of mass (surface) before export
                    faces_up = (p for p in ob.data.polygons)# if p.normal.z > 0) #Not used right now
                    ob2 = max(faces_up, key=lambda f: f.area) #Get largest area in the collection
                    n = N @ ob2.normal
                    if mytool.my_exportobjectlist == "Windows2":
                        n = mathutils.Vector((0,-1,0)) #Default vector, pointing -Y
                        n.rotate(ob.rotation_euler)
                    if mytool.my_exportobjectlist == "Windows3":
                        n = mathutils.Vector((0,0,1)) #Default vector, pointing +Z
                        n.rotate(ob.rotation_euler)
                        #print (n)
                    #Find width and heigh. Probably depends on object type so I use two methods and use the largest
                    #For vertical windows it looks that the x or y is width and z is height
                    #For sloping windows x is with and y is height. z is depth 
                    if (ob.dimensions[1]) > (ob.dimensions[2]): #Sloping window
                        dimensionwidth = (ob.dimensions[0])
                        dimensionheight = (ob.dimensions[1])
                        dimensiondepth = (ob.dimensions[2])
                    if (ob.dimensions[1]) < (ob.dimensions[2]): #Horizontal window
                        dimensionwidth = (ob.dimensions[0]) #Width or depth, hard to say
                        dimensiondepth = (ob.dimensions[1]) #Width or depth, hard to say
                        dimensionheight = (ob.dimensions[2]) #Height
                    largestdimensionwidth = (maximum(dimensionwidth, dimensiondepth)) #Pick the largest, most important for vertical windows
                    verts = ob.data.vertices #Get all corners
                    calculatedwidth = max(v.co.x for v in verts) - min(v.co.x for v in verts) #Get largest value, this is only in x, not in the normal plane. One way would be to use the IFC/Speckle data.
                    calculateddepth = max(v.co.y for v in verts) - min(v.co.y for v in verts) #Get smallest value
                    largestcalculatedwidth = (maximum(calculatedwidth, calculateddepth)) #Make sure the largest of with and depth is choosen
                    width = (maximum(largestdimensionwidth, largestcalculatedwidth))
                    #width = width -0.4 #Not used but might be an option to change the size manually
                    #Possibility to rotate normal 90 degrees:
                    #nx = (normal.x * math.cos(math.radians(90))) - (normal.y * math.sin(math.radians(90)))
                    #ny = (normal.x * math.sin(math.radians(90))) + (normal.y * math.cos(math.radians(90)))
                    calculatedheight = max(v.co.z for v in verts) - min(v.co.z for v in verts)
                    height = (maximum(dimensionheight, calculatedheight))
                    #height = height -0.4
                    #If it is a IFCWIndow, use the given width
                    #Right now it assumes mm, probably not sure
                    #There is a bug in height
                    if ob.name.startswith("IfcWindow"):
                        ifc_entity = tool.Ifc.get_entity(ob) #gets the Ifc Entity from the Blender object
                        #Unit 
                        #IFCHeightm = ifc_entity.OverallHeight/1000
                        #IFCWidthm = ifc_entity.OverallWidth#/1000
                        #height = IFCHeightm
                        #width = IFCWidthm
                    #Get Speckle category, type and family
                    #Check if a name exists. We should also check if name is valid and unique
                    custompropertyexists = bpy.data.objects[str(ob.name)].get('type') is not None
                    if custompropertyexists == True:
                        panetype = (str(bpy.data.objects[str(ob.name)]['type']))
                    elif custompropertyexists == False:
                        panetype = "Undefined"
                    #If it is a IFCwindow this name has priority
                    if ob.name.startswith("IfcWindow"):
                        ifc_entity = tool.Ifc.get_entity(ob) #gets the Ifc Entity from the Blender object
                        panetype = str(ifc_entity.ObjectType)
                    #Produce script
                    print(str(width))
                    #if width > 0.2: #Do not export very small windows and doors to avoid errors
                    ICEScript.write("((")
                    ICEScript.write(str(-centre.x)) #Change direction 
                    ICEScript.write(" ")
                    ICEScript.write(str(-centre.y)) #Change direction 
                    ICEScript.write(" ")
                    ICEScript.write(str(centre.z))
                    ICEScript.write(") (")
                    ICEScript.write(str(-n[0])) #Change direction (invert is fine)
                    ICEScript.write(" ")
                    ICEScript.write(str(-n[1])) #Change direction (invert is fine)
                    ICEScript.write(" ")
                    ICEScript.write(str(n[2]))
                    if mytool.my_exportobjectlist == "Windows" or mytool.my_exportobjectlist == "Windows2" or mytool.my_exportobjectlist == "Windows3":
                        ICEScript.write(") (AGGREGATE :T IFCIM_WINDOW :N ")
                    elif mytool.my_exportobjectlist == "Doors":
                        ICEScript.write(") (AGGREGATE :T IFCIM_DOOR :N ")
                    ICEScript.write('"')
                    ICEScript.write(str(ob.name))
                    ICEScript.write('"')
                    ICEScript.write(") (:PAR :N DY :V ")
                    ICEScript.write(str(height))
                    ICEScript.write(") (:PAR :N DX :V ")
                    ICEScript.write(str(width))
                    ICEScript.write(") (:PAR :N STYLE :V ")
                    ICEScript.write('"')
                    ICEScript.write(panetype)
                    ICEScript.write('"))'+ '\n')
                        
            ICEScript.close()

            #Adjust long file names
            # Read in the file
            if mytool.my_exportobjectlist == "Windows" or mytool.my_exportobjectlist == "Windows2" or mytool.my_exportobjectlist == "Windows3":
                with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + 'ImportWindows.txt', 'r') as file :
                    filedata = file.read()
                    # Replace the target string
                    filedata = filedata.replace("Objects.Geometry.Mesh -- ", "")
                    # Write the file out again
                    with open(bpy.path.abspath(str(mytool.scriptfolder_path)) + 'ImportWindows.txt', 'w') as file:
                        file.write(filedata)
            elif mytool.my_exportobjectlist == "Doors":
                with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + 'ImportDoors.txt', 'r') as file :
                    filedata = file.read()
                    # Replace the target string
                    filedata = filedata.replace("Objects.Geometry.Mesh -- ", "")
                    # Write the file out again
                    with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + 'ImportDoors.txt', 'w') as file:
                        file.write(filedata)
            return {'FINISHED'}
                     
# ------------------------------------------------------------------------
#    Menus
# ------------------------------------------------------------------------

class OBJECT_MT_CustomMenu(bpy.types.Menu):
    bl_label = "Select"
    bl_idname = "OBJECT_MT_custom_menu"

    def draw(self, context):
        layout = self.layout
        # Built-in operators
        layout.operator("object.select_all", text="Select/Deselect All").action = 'TOGGLE'
        layout.operator("object.select_all", text="Inverse").action = 'INVERT'
        layout.operator("object.select_random", text="Random")

# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------

class OBJECT_PT_ICEBridgePanel1(Panel):
    bl_label = "Settings"
    bl_idname = "OBJECT_PT_ICEBridge_panel1"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool

        layout.prop(mytool, "my_version", text="") 
        layout.prop(mytool, "scriptfolder_path")
         #layout.separator()
        
class OBJECT_PT_ICEBridgePanel2(Panel):
    bl_label = "Select Objects"
    bl_idname = "OBJECT_PT_ICEBridge_panel2"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        layout.menu(OBJECT_MT_CustomMenu.bl_idname, text="Presets", icon="SCENE")
        layout.prop(mytool, "my_filterlist", text="Filter")
        row = layout.row()   # A new row
        row = layout.row(align = True)   # Focus on this row
        #layout.operator("wm.ICEHide", icon="SELECT_INTERSECT")
        row = layout.row()   # A new row
        layout.operator("wm.select_filtered_objects", icon="SELECT_INTERSECT")
        #layout.separator()
        
class OBJECT_PT_ICEBridgePanel3(Panel):
    bl_label = "Object Operations"
    bl_idname = "OBJECT_PT_ICEBridge_panel3"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        layout.prop(mytool, "my_objectoperationlist", text="")
        row = layout.row(align = True)   # Focus on this row
        #Only enable used input
        if bpy.context.scene.my_tool.my_objectoperationlist == "ColorObject":
            row.enabled = True
        if bpy.context.scene.my_tool.my_objectoperationlist != "ColorObject":
            row.enabled = False
        row.prop(mytool, "my_colorlist")
        row.prop(mytool, "my_colortransparency")
        row = layout.row()   # A new row
        row = layout.row(align = True)   # Focus on this row
        #Only enable used input
        if bpy.context.scene.my_tool.my_objectoperationlist == "MoveGivenZ" or bpy.context.scene.my_tool.my_objectoperationlist == "ExtrudeGivenDistance" or bpy.context.scene.my_tool.my_objectoperationlist == "MoveToGivenZ" or bpy.context.scene.my_tool.my_objectoperationlist == "ExtrudeToGivenZ":
            row.enabled = True
        if bpy.context.scene.my_tool.my_objectoperationlist != "MoveGivenZ" and bpy.context.scene.my_tool.my_objectoperationlist != "ExtrudeGivenDistance" and bpy.context.scene.my_tool.my_objectoperationlist != "ExtrudeToGivenZ" and bpy.context.scene.my_tool.my_objectoperationlist != "MoveToGivenZ":
            row.enabled = False
        row.prop(mytool, "my_height")
        row = layout.row()   # A new row
        layout.operator("wm.perform_operation", icon="PLAY")
        
                
class OBJECT_PT_ICEBridgePanel4(Panel):
    bl_label = "Export Selected Objects"
    bl_idname = "OBJECT_PT_ICEBridge_panel4"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        layout.prop(mytool, "my_exportobjectlist", text="")
        
        row = layout.row()   # A new row
        if bpy.context.scene.my_tool.my_exportobjectlist == "BuildingBodies" or bpy.context.scene.my_tool.my_exportobjectlist == "Zones" or bpy.context.scene.my_tool.my_exportobjectlist == "BuildingBodiesAndZones":
            row.enabled = True
        if bpy.context.scene.my_tool.my_exportobjectlist != "BuildingBodies" and bpy.context.scene.my_tool.my_exportobjectlist != "Zones" and bpy.context.scene.my_tool.my_exportobjectlist != "BuildingBodiesAndZones":
            row.enabled = False
        row.prop(mytool, "my_creategeometry")

        row = layout.row()   # A new row
        #Only enable used input
        if bpy.context.scene.my_tool.my_exportobjectlist == "BuildingBodiesFromRoof" or bpy.context.scene.my_tool.my_exportobjectlist == "PrismaticBuildingBodies" or bpy.context.scene.my_tool.my_exportobjectlist == "PrismaticZones":
            row.enabled = True
        if bpy.context.scene.my_tool.my_exportobjectlist != "BuildingBodiesFromRoof" and bpy.context.scene.my_tool.my_exportobjectlist != "PrismaticBuildingBodies" and bpy.context.scene.my_tool.my_exportobjectlist != "PrismaticZones":
            row.enabled = False
        row.prop(mytool, "my_prismaticheight")
        
        row = layout.row()   # A new row
        #Only enable used input
        if bpy.context.scene.my_tool.my_exportobjectlist == "ExternalObjects":
            row.enabled = True
        if bpy.context.scene.my_tool.my_exportobjectlist != "ExternalObjects":
            row.enabled = False
        row.prop(mytool, "externalobjetcsfolder_path")
        
        row = layout.row(align = True)   # Focus on this row
        #Only enable used input
        if bpy.context.scene.my_tool.my_exportobjectlist == "ExternalObjects":
            row.enabled = True
        if bpy.context.scene.my_tool.my_exportobjectlist != "ExternalObjects":
            row.enabled = False
        row.prop(mytool, "my_shadingbool")
        row.prop(mytool, "my_transparency")
        
        row = layout.row()   # A new row
        layout.operator("wm.ice_export_script", icon="COPYDOWN")


# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyICEProperties,
    WM_OT_Export,
    WM_OT_PerformOperation,
    WM_OT_SelectFilteredObjects,
    OBJECT_MT_CustomMenu,
    OBJECT_PT_ICEBridgePanel1,
    OBJECT_PT_ICEBridgePanel2,
    OBJECT_PT_ICEBridgePanel3,
    OBJECT_PT_ICEBridgePanel4
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.my_tool = PointerProperty(type=MyICEProperties)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_tool

if __name__ == "__main__":
    register()