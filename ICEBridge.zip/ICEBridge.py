"""
[Blender and Python] Sending data to IDA ICE
Max Tillberg - August 2022
Email: max.tillberg@equa.se
--------
Copyright (c) 2022 Equa Simulation AB

Bugs:
    - Roof windows from IFC files have wrong height.
    - External objects are not visible if not placed in ARCDATA and objects can only e imported oce with script
    - Zone and building bodies tends to be placed on top of each other origo
    
To do:
    - Get data from IFC-files if possible
    - Rename building bodies to they do not conflict with zones
    - Merge building bodies
    - Possible features: Help buttons, Clear temp folder, Create zones and building bodies from floor plans, 
"""

bl_info = {
    # required
    'name': 'ICE Bridge',
    'blender': (3, 0, 0),
    'category': 'Object',
    # optional
    'version': (0, 6, 5),
    'author': 'Max Tillberg',
    'description': 'Export tool to IDA ICE',
}

#IFC Test
#from blenderbim.bim.ifc import IfcStore
#ifc_data = IfcStore.get_file()

#windows = ifc_data.by_type('IfcWindow')
#for window in windows:
#    print(window.is_a())
#    print(window.GlobalId)
#    print(window.OverallHeight)
#    print(window.OverallWidth)
#    geometry = window.Representation.Representations[0].Items[0] # An IfcExtrudedAreaSolid in this example
#    print(geometry)
    #print(geometry.Position.Location[0])
    #print(geometry.Position.Location[0]) # The centroid of the wall, so if the wall axis goes from (0, 0, 0) to (4, 0, 0) it will be (2, 0, 0)
    #print(geometry.ExtrudeDirection) # A vector pointing up (0, 0, 1)

#import bpy
#selection = bpy.context.selected_objects
###print(IfcStore.get_file())
#for  obj in selection: 
#    print("start------------------------------------")
#    if obj.name.startswith("IfcWindow"):
#        print (obj.active_material)

import bpy
import os
import mathutils
import math
from mathutils import Matrix

#Function to determine largest object
def maximum(a, b):
    if a >= b:
        return a
    else:
        return b

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       FloatVectorProperty,
                       EnumProperty,
                       PointerProperty,
                       )
from bpy.types import (Panel,
                       Menu,
                       Operator,
                       PropertyGroup,
                       )

# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------

class MyICEProperties(PropertyGroup):

    my_shadingbool: BoolProperty(
        name="Shading",
        description="If the exported objects should shade or not",
        default = True
        )

    my_transparency: IntProperty(
        name = "Transparency",
        description="Transparency of externalexported external object",
        default = 0,
        min = 0,
        max = 100
        )
#    my_float: FloatProperty(
#        name = "Float Value",
#        description = "A float property",
#        default = 23.7,
#        min = 0.01,
#        max = 30.0
#        )

#    my_float_vector: FloatVectorProperty(
#        name = "Insert point",
#        description="Insert point in IDA ICE",
#        default=(0, 0, 0), 
#        min= -1000, # float
#        max = 1000
#    ) 

#    scriptname: StringProperty(
#        name="Script name",
#        description="Name of script. The default name can be changed if needed",
#        default="Why does",
#        maxlen=1024,
#        options={'TEXTEDIT_UPDATE'},
#        )

    scriptfolder_path: StringProperty(
        name = "Script folder",
        description="Choose a directory to store script and geometry files in",
        default="",
        maxlen=1024,
        subtype='DIR_PATH'
        )
        
    externalobjetcsfolder_path: StringProperty(
        name = "External Objects folder",
        description="Choose a directory to store external objects",
        default="",
        maxlen=1024,
        subtype='DIR_PATH'
        )

    my_filterlist: EnumProperty(
        name="Filter Objects:",
        description="Select property to filter object by",
        items=[ ('IFCSpace', "IFCSpace", "IFCSpace"),
                ('IFCWindow', "IFCWindow", "IFCWindow"),
                ('IFCDoor', "IFCDoor", "IFCDoor"),
                ('Glazed', "Glazed", "Glazed"),
                ('Glass', "Glass", "Glass"),
                ('Panel', "Panel", "Panel"),
                ('IFCWall', "IFCWall", "IFCWall"),
                ('IFCRoof', "IFCRoof", "IFCRoof"),
                ('IFCSite', "IFCSite", "IFCSite"),
                ('IFCSlab', "IFCSlab", "IFCSlab"),
                ('IFCFurnishing', "IFCFurnishing", "IFCFurnishing"),
                ('Proxy', "Proxy", "Proxy"),
                ('Glass as material', "Glass as material", "Glass as material"),
                ('@Windows', "@Windows", "Speckle Windows collection"),
                ('@Rooms', "@Rooms", "Speckle Rooms collection"),
                ('@Doors', "@Doors", "Speckle Doors collection"),
                ('@Curtain Panels', "@Curtain Panels", "Speckle Curtain Panels collection"),
                ('@Curtain Systems', "@Curtain Systems", "Speckle Curtain Systems collection"),
                ('@Walls', "@Walls", "Speckle Walls collection"),
                ('@Floors', "@Floors", "Speckle Floors collection"),
                ('@Grids', "@Grids", "Speckle Grids collection"),
                ('@Stairs', "@Stairs", "Speckle Stairs collection"),
                ('@Cailings', "@Ceilings", "Speckle Ceilings collection"),
                ('@Railings', "@Railings", "Speckle Railings collection"),
               ]
        )
    my_exportobjectlist: EnumProperty(
        name="Export Objects:",
        description="Choose what object type to export selected abojects as.",
        items=[ ('BuildingBodies', "Building bodies from volumes", "Volumes must be closed and made of planar surfaces. Each selected object will create one building body"),
                ('Zones', "Zones from volumes", "Volumes must be closed and made of planar surfaces. Each selected object will create one zone"),
                ('BuildingBodiesAndZones', "Building bodies and Zones from volumes", "Volumes must be closed and made of planar surfaces. Each selected object will create one building body and one zone"),
                ('Windows', "Windows from large surfaces", "Windows should be as planar as possible"),
                ('Windows2', "Windows from IFCWindows (-Y)", "Windows without large surfaces created by IFC"),
                ('Windows3', "Windows from IFCWindows (+Z)", "Windows without large surfaces created by IFC"),
                ('Doors', "Doors from large surfaces", "Doors should be as planar as possible"),
                ('ExternalObjects', "External objects", "External objects can be shading and semitranparent. Group objects with similar properties."),
               ]
        )

            
    my_objectoperationlist: EnumProperty(
        name="Object operation:",
        description="Choose what operation to perform on selected objects.",
        items=[ ('CenterOfMass', "Set Origin to Center of Mass", "This is important to get midpoint of windows and doors correct"),
                ('Delete', "Delete selected objects", "Delete Selected Objects"),
                ('Hide', "Hide selected objects", "Hide Selected Objects"),
                ('Show', "Show all objects", "Show all Objects"),
                ('Join', "Join selected objects", "Join objects into the selected. Useful for complex building bodies, zones and external objects"),
                ('RemoveGaps', "Revove gaps between selected zones", "Extend zones to center of wall"),
               ]
        )

    my_version: EnumProperty(
        name="IDA ICE version:",
        description="Choose what IDA ICE version to export to.",
        items=[ ('ICE48', "IDA ICE 4.8 or earlier", ""),
                #('ICE50', "IDA ICE 5.0 or later", ""),
               ]
        )

# ------------------------------------------------------------------------
#    Operators /Buttons to perform actions
# ------------------------------------------------------------------------

class WM_OT_SelectFilteredObjects(Operator):
    bl_label = "Select Filtered Objects"
    bl_idname = "wm.select_filtered_objects"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool

        if mytool.my_filterlist == "IFCSpace":
            bpy.ops.object.select_pattern(pattern='*IFCSpace*')
        if mytool.my_filterlist == "IFCWindow":
            bpy.ops.object.select_pattern(pattern='*IFCWindow*')
        if mytool.my_filterlist == "IFCDoor":
            bpy.ops.object.select_pattern(pattern='*IFCDoor*')
        if mytool.my_filterlist == "Glazed":
            bpy.ops.object.select_pattern(pattern='*Glazed*')
        if mytool.my_filterlist == "Glass":
            bpy.ops.object.select_pattern(pattern='*Glass*')
        if mytool.my_filterlist == "Panel":
            bpy.ops.object.select_pattern(pattern='*Panel*')
        if mytool.my_filterlist == "IFCWall":
            bpy.ops.object.select_pattern(pattern='*IFCWall*')
        if mytool.my_filterlist == "IFCRoof":
            bpy.ops.object.select_pattern(pattern='*IFCRoof*')
        if mytool.my_filterlist == "IFCSite":
            bpy.ops.object.select_pattern(pattern='*IFCSite*')
        if mytool.my_filterlist == "IFCSlab":
            bpy.ops.object.select_pattern(pattern='*IFCSlab*')
        if mytool.my_filterlist == "IFCFurnishing":
            bpy.ops.object.select_pattern(pattern='*IFCFurnishing*')
        if mytool.my_filterlist == "Proxy":
            bpy.ops.object.select_pattern(pattern='*Proxy*')
        if mytool.my_filterlist == "Glass as material":
            for obj in bpy.context.visible_objects:
                for m in obj.material_slots:
                    if "Glass" in m.name:
                        obj.select_set(True)
        if mytool.my_filterlist == "@Windows":
            for obj in bpy.data.collections["@Windows"].all_objects:                
                obj.select_set(True)
        if mytool.my_filterlist == "@Rooms":
            for obj in bpy.data.collections["@Rooms"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Doors":
            for obj in bpy.data.collections["@Doors"].all_objects:
                obj.select_set(True) 
        if mytool.my_filterlist == "@Curtain Panels":
            for obj in bpy.data.collections["@Curtain Panels"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Curtain Systems":
            for obj in bpy.data.collections["@Curtain Systems"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Walls":
            for obj in bpy.data.collections["@Walls"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Floors":
            for obj in bpy.data.collections["@Floors"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Curtain Panels":
            for obj in bpy.data.collections["@Curtain Panels"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Grids":
            for obj in bpy.data.collections["@Grids"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Stairs":
            for obj in bpy.data.collections["@Stairs"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Ceilings":
            for obj in bpy.data.collections["@Ceilings"].all_objects:
                obj.select_set(True)
        if mytool.my_filterlist == "@Railings":
            for obj in bpy.data.collections["@Railings"].all_objects:
                obj.select_set(True)
        return {'FINISHED'}


class WM_OT_PerformOperation(Operator):
    bl_label = "Perform Operation"
    bl_idname = "wm.perform_operation"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        if mytool.my_objectoperationlist == "CenterOfMass":
            selection = bpy.context.selected_objects
            for obj in selection:
               if obj.type=="MESH":
                    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
        if mytool.my_objectoperationlist == "Delete":
            selection = bpy.context.selected_objects
            for obj in selection:
                bpy.data.objects.remove(obj)
        if mytool.my_objectoperationlist == "Hide":
            selection = bpy.context.selected_objects
            for obj in selection:
                obj.hide_set(True)
        if mytool.my_objectoperationlist == "Show":
            for obj in bpy.context.scene.objects:
                obj.hide_set(False)                
        if mytool.my_objectoperationlist == "Join":
            selection = bpy.context.selected_objects
            obs = []
            for obj in selection:
                if obj.type == 'MESH':
                    obs.append(obj)
            ctx = bpy.context.copy()
            # one of the objects to join
            ctx['active_object'] = obs[0]
            ctx['selected_editable_objects'] = obs
            # We need the scene bases as well for joining.
            bpy.ops.object.join(ctx)
        if mytool.my_objectoperationlist == "RemoveGaps": 
            #Code from https://github.com/IfcOpenShell/IfcOpenShell/commit/eb0f2de197c94e18d6eed83e56351e1c189e07ed#diff-7a3448a810418b98f5db644b11c1bf9ad0452c88545991ecc1eda3f65c929895 
            threshold = 0.5
            processed_polygons = set()

            for obj in bpy.context.selected_objects:
                if obj.type != "MESH":
                    continue
                for polygon in obj.data.polygons:
                    center = obj.matrix_world @ polygon.center
                    distance = None
                    for obj2 in bpy.context.selected_objects:
                        if obj2 == obj or obj.type != "MESH":
                            continue
                        result = obj2.ray_cast(
                            obj2.matrix_world.inverted() @ center,
                            polygon.normal,
                            distance=threshold
                        )
                        if not result[0]:
                            continue
                        hit = obj2.matrix_world @ result[1]
                        distance = (hit - center).length / 2
                        if distance < 0.01:
                            distance = None
                            break

                        if (obj2.name, result[3]) in processed_polygons:
                            distance *= 2
                            continue

                        offset = polygon.normal * distance * -1
                        processed_polygons.add((obj2.name, result[3]))
                        for v in obj2.data.polygons[result[3]].vertices:
                            obj2.data.vertices[v].co += offset
                        break
                    if distance:
                        offset = polygon.normal * distance
                        processed_polygons.add((obj.name, polygon.index))
                        for v in polygon.vertices:
                            obj.data.vertices[v].co += offset
        return {'FINISHED'}

class WM_OT_Export(Operator):
    bl_label = "Export to IDA ICE"
    bl_idname = "wm.ice_export_script"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        #Use fixed script names based upon object type
        if mytool.my_exportobjectlist == "BuildingBodies":
            scriptname = "ImportBuildingBodies.txt"
        if mytool.my_exportobjectlist == "Zones":
            scriptname = "ImportZones.txt"
        if mytool.my_exportobjectlist == "BuildingBodiesAndZones":
            scriptname = "ImportBuildingBodiesAndZones.txt"
        if mytool.my_exportobjectlist == "Windows":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Windows2":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Windows3":
            scriptname = "ImportWindows.txt"
        if mytool.my_exportobjectlist == "Doors":
            scriptname = "ImportDoors.txt"
        if mytool.my_exportobjectlist == "ExternalObjects":
            scriptname = "ImportExternalObjects.txt"
        ICEScript=open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname,'w')
        #Divide the code in two parts, scripts that exports geometries and scripts that does not
        if mytool.my_exportobjectlist == "BuildingBodies" or mytool.my_exportobjectlist == "Zones" or mytool.my_exportobjectlist == "BuildingBodiesAndZones" or mytool.my_exportobjectlist == "ExternalObjects":
            view_layer = bpy.context.view_layer
            obj_active = view_layer.objects.active
            selection = bpy.context.selected_objects
            bpy.ops.object.select_all(action='DESELECT')
            if mytool.my_exportobjectlist == "ExternalObjects":
                ICEScript.write('(:UPDATE [@]' +'\n')
                ICEScript.write('(:ADD (AGGREGATE :N ARCDATA)' + '\n')

            for obj in selection:
                obj.select_set(True)
                #Get Speckle category, type and family
                #Check if a name exists. We should also check if name is valid and unique
                custompropertyexists = bpy.data.objects[str(obj.name)].get('name') is not None
                if custompropertyexists == True:
                    fn = (str(bpy.data.objects[str(obj.name)]['name']))
                elif custompropertyexists == False:
                    fn = str(obj.name)
                #Replace long Speckle names
                fn = fn.replace("Objects.Geometry.Mesh -- ", "")
                fn = fn.replace('/', '_') #IFC-names can be invalid file names
                fn = fn.replace(':', '_') #IFC-names can be invalid file names
                fn = fn.replace('.', '_') #IFC-names can be invalid file names
                fnorg = fn #save the zone name for later
                fn = (str(bpy.path.abspath(mytool.scriptfolder_path)) + str(fn)) #Get path
                shadename = (str(bpy.path.abspath(mytool.externalobjetcsfolder_path)) + str(fnorg)) #Get path
                #Exported location for obj-files should be places in tempfolder with the exception of shading objects that are permanent
                if mytool.my_exportobjectlist == "BuildingBodies":
                    fp = fn  + '.obj'
                if mytool.my_exportobjectlist == "Zones":
                    fp = fn  + '.obj'
                if mytool.my_exportobjectlist == "BuildingBodiesAndZones":
                    fp = fn  + '.obj'
                if mytool.my_exportobjectlist == "ExternalObjects":
                    fp = shadename  + '.obj'
                #some exporters only use the active object
                view_layer.objects.active = obj
                bpy.ops.export_scene.obj(filepath=fp, axis_forward='-Y', axis_up='Z', use_selection=True, check_existing=True)
                #The actual script varies with object type
                if mytool.my_exportobjectlist == "BuildingBodies":
                    ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'building-body ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n')
                if mytool.my_exportobjectlist == "Zones":
                    ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'zone ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n' + '(:UPDATE [@](:REMOVE "' + str(fnorg) + '-s"))'+'\n')
                if mytool.my_exportobjectlist == "BuildingBodiesAndZones":
                    ICEScript.write('(:call Import-Geometry (:call ice-3d-pane [@] t t)' +" '" + 'zone ' + '(0 0 0)' + ' 0 "' + fp + '")' +'\n')
                if mytool.my_exportobjectlist == "ExternalObjects":
                    #print ("kalle")
                    ICEScript.write('((AGGREGATE :N "' + fnorg + '" :T PICT3D)(:PAR :N FILE :V "' + fp + '")(:PAR :N TRANSPARENCY :V ' + str(mytool.my_transparency) + ')(:PAR :N SHADOWING :V :' + str(mytool.my_shadingbool) + '))' +'\n')
                obj.select_set(False)
            if mytool.my_exportobjectlist == "ExternalObjects":
                ICEScript.write('))')
            
            ICEScript.close()
            view_layer.objects.active = obj_active

            for obj in selection:
                obj.select_set(True)

            #Replace  \ with \\
            # Read in the file
            with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'r') as file :
              filedata = file.read()

            # Replace the target string
            filedata = filedata.replace("\\", "\\\\")

            # Write the file out again
            with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + scriptname, 'w') as file:
              file.write(filedata)

            return {'FINISHED'}
        #Code for exporting windows and doors
        if mytool.my_exportobjectlist == "Windows" or mytool.my_exportobjectlist == "Windows2" or mytool.my_exportobjectlist == "Windows3" or mytool.my_exportobjectlist == "Doors":

            from bpy import context as C

            for ob in C.selected_objects:
                mw = ob.matrix_world #Normal direction should be according to world
                N = mw.inverted_safe().transposed().to_3x3() #Normal direction should be according to world
                #Make sure only meshes are selected
                if ob.type=='MESH': #Ensure origin is centered on bounding box center
                    if bpy.ops.object.type=='MESH':
                        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
                    centre = ob.location  # Does this work for all objects? All objects should be changed mnually manually by using Object-Set Origin-Origin to center of mass (surface) before export
                    faces_up = (p for p in ob.data.polygons)# if p.normal.z > 0) #Not used right now
                    ob2 = max(faces_up, key=lambda f: f.area) #Get largest area in the collection
                    n = N @ ob2.normal
                    if mytool.my_exportobjectlist == "Windows2":
                        n = mathutils.Vector((0,-1,0)) #Default vector, pointing -Y
                        n.rotate(ob.rotation_euler)
                    if mytool.my_exportobjectlist == "Windows3":
                        n = mathutils.Vector((0,0,1)) #Default vector, pointing +Z
                        n.rotate(ob.rotation_euler)
                    #Find width and heigh. Probably depends on object type so I use two methods and use the largest
                    dimensionwidth = (ob.dimensions[0])
                    dimensiondepth = (ob.dimensions[1])
                    dimensionheight = (ob.dimensions[2])
                    largestdimensionwidth = (maximum(dimensionwidth, dimensiondepth))
                    verts = ob.data.vertices #Get all corners
                    calculatedwidth = max(v.co.x for v in verts) - min(v.co.x for v in verts) #Get largest value, this is only in x, not in the normal plane. One way would be to use the IFC/Speckle data.
                    calculateddepth = max(v.co.y for v in verts) - min(v.co.y for v in verts) #Get smallest value
                    largestcalculatedwidth = (maximum(calculatedwidth, calculateddepth)) #Make sure the largest of with and depth is choosen
                    appwidth = (maximum(largestdimensionwidth, largestcalculatedwidth))
                    #Possibility to rotate normal 90 degrees:
                    #nx = (normal.x * math.cos(math.radians(90))) - (normal.y * math.sin(math.radians(90)))
                    #ny = (normal.x * math.sin(math.radians(90))) + (normal.y * math.cos(math.radians(90)))
                    calculatedheight = max(v.co.z for v in verts) - min(v.co.z for v in verts)
                    height = (maximum(dimensionheight, calculatedheight))
                    
                    #Get Speckle category, type and family
                    #Check if a name exists. We should also check if name is valid and unique
                    custompropertyexists = bpy.data.objects[str(ob.name)].get('type') is not None
                    if custompropertyexists == True:
                        panetype = (str(bpy.data.objects[str(ob.name)]['type']))
                    elif custompropertyexists == False:
                        panetype = "Undefined"
                    
                    #Produce script
                    if appwidth > 0.2: #Do not export very small windows and doors to avoid errors
                        ICEScript.write("((")
                        ICEScript.write(str(-centre.x)) #Change direction 
                        ICEScript.write(" ")
                        ICEScript.write(str(-centre.y)) #Change direction 
                        ICEScript.write(" ")
                        ICEScript.write(str(centre.z))
                        ICEScript.write(") (")
                        ICEScript.write(str(-n[0])) #Change direction (invert is fine)
                        ICEScript.write(" ")
                        ICEScript.write(str(-n[1])) #Change direction (invert is fine)
                        ICEScript.write(" ")
                        ICEScript.write(str(n[2]))
                        if mytool.my_exportobjectlist == "Windows" or mytool.my_exportobjectlist == "Windows2" or mytool.my_exportobjectlist == "Windows3":
                            ICEScript.write(") (AGGREGATE :T IFCIM_WINDOW :N ")
                        elif mytool.my_exportobjectlist == "Doors":
                            ICEScript.write(") (AGGREGATE :T IFCIM_DOOR :N ")
                        ICEScript.write('"')
                        ICEScript.write(str(ob.name))
                        ICEScript.write('"')
                        ICEScript.write(") (:PAR :N DY :V ")
                        ICEScript.write(str(height))
                        ICEScript.write(") (:PAR :N DX :V ")
                        ICEScript.write(str(appwidth))
                        ICEScript.write(") (:PAR :N STYLE :V ")
                        ICEScript.write('"')
                        ICEScript.write(panetype)
                        ICEScript.write('"))'+ '\n')
            ICEScript.close()

            #Adjust long file names
            # Read in the file
            if mytool.my_exportobjectlist == "Windows" or mytool.my_exportobjectlist == "Windows2" or mytool.my_exportobjectlist == "Windows3":
                with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + 'ImportWindows.txt', 'r') as file :
                    filedata = file.read()
                    # Replace the target string
                    filedata = filedata.replace("Objects.Geometry.Mesh -- ", "")
                    # Write the file out again
                    with open(bpy.path.abspath(str(mytool.scriptfolder_path)) + 'ImportWindows.txt', 'w') as file:
                        file.write(filedata)
            elif mytool.my_exportobjectlist == "Doors":
                with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + 'ImportDoors.txt', 'r') as file :
                    filedata = file.read()
                    # Replace the target string
                    filedata = filedata.replace("Objects.Geometry.Mesh -- ", "")
                    # Write the file out again
                    with open(str(bpy.path.abspath(mytool.scriptfolder_path)) + 'ImportDoors.txt', 'w') as file:
                        file.write(filedata)
            return {'FINISHED'}
                     
# ------------------------------------------------------------------------
#    Menus
# ------------------------------------------------------------------------

class OBJECT_MT_CustomMenu(bpy.types.Menu):
    bl_label = "Select"
    bl_idname = "OBJECT_MT_custom_menu"

    def draw(self, context):
        layout = self.layout
        #bpy.context.scene.my_tool.scriptname = "jalle"
        # Built-in operators
        layout.operator("object.select_all", text="Select/Deselect All").action = 'TOGGLE'
        layout.operator("object.select_all", text="Inverse").action = 'INVERT'
        layout.operator("object.select_random", text="Random")

# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------

class OBJECT_PT_ICEBridgePanel1(Panel):
    bl_label = "Settings"
    bl_idname = "OBJECT_PT_ICEBridge_panel1"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool

        layout.prop(mytool, "my_version", text="") 
        layout.prop(mytool, "scriptfolder_path")
         #layout.separator()
        
class OBJECT_PT_ICEBridgePanel2(Panel):
    bl_label = "Select Objects"
    bl_idname = "OBJECT_PT_ICEBridge_panel2"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        layout.menu(OBJECT_MT_CustomMenu.bl_idname, text="Presets", icon="SCENE")
        layout.prop(mytool, "my_filterlist", text="Filter")
        layout.operator("wm.select_filtered_objects")
        #layout.separator()
        
class OBJECT_PT_ICEBridgePanel3(Panel):
    bl_label = "Object Operations"
    bl_idname = "OBJECT_PT_ICEBridge_panel3"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        layout.prop(mytool, "my_objectoperationlist", text="")
        layout.operator("wm.perform_operation")
        
                
class OBJECT_PT_ICEBridgePanel4(Panel):
    bl_label = "Export Selected Objects"
    bl_idname = "OBJECT_PT_ICEBridge_panel4"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "ICE Bridge"
    bl_context = "objectmode"   

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        layout.prop(mytool, "my_exportobjectlist", text="")
        
        row = layout.row()   # A new row
        #Only enable used input
        if bpy.context.scene.my_tool.my_exportobjectlist == "ExternalObjects":
            row.enabled = True
        if bpy.context.scene.my_tool.my_exportobjectlist != "ExternalObjects":
            row.enabled = False
        row.prop(mytool, "externalobjetcsfolder_path")
        
        row = layout.row(align = True)   # Focus on this row
        #Only enable used input
        if bpy.context.scene.my_tool.my_exportobjectlist == "ExternalObjects":
            row.enabled = True
        if bpy.context.scene.my_tool.my_exportobjectlist != "ExternalObjects":
            row.enabled = False
        row.prop(mytool, "my_shadingbool")
        row.prop(mytool, "my_transparency")
        
        row = layout.row()   # A new row
        layout.operator("wm.ice_export_script")


# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyICEProperties,
    WM_OT_Export,
    WM_OT_PerformOperation,
    WM_OT_SelectFilteredObjects,
    OBJECT_MT_CustomMenu,
    OBJECT_PT_ICEBridgePanel1,
    OBJECT_PT_ICEBridgePanel2,
    OBJECT_PT_ICEBridgePanel3,
    OBJECT_PT_ICEBridgePanel4
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.my_tool = PointerProperty(type=MyICEProperties)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_tool


if __name__ == "__main__":
    register()