import h5py
import pandas as pd
import numpy as np
from datetime import datetime
import copy
from util50 import *

def get_origo(building):
    zones = call_ida_api_function(ida_lib.getChildrenOfType,building,b"ZONE")
    results = pd.DataFrame(columns = ['Zone_name', 'Origo_x', 'Origo_y', 'Origo_z'])
 
    for zone in zones:
        zone_val = zone['value']
        print(zone_val)
        zone_name = ida_get_name(zone_val)  
        zone_level = ida_get_named_child(building, zone_name)
        geometry = ida_get_named_child(zone_level, "GEOMETRY")
        z = ida_get_named_child(geometry, "FLOOR_HEIGHT_FROM_GROUND")
        origo_z = ida_get_value(z)

        origo = ida_get_named_child(geometry, "ORIGIN")
        origo_val = ida_get_value(origo)
        origo_x = origo_val[0]['value']
        origo_y = origo_val[1]['value']
 
        results.loc[results.shape[0]] = [zone_name, origo_x, origo_y, origo_z]        

    return results

def get_origo_zones(model):
    # Connect to the IDA API instance of the process you just started in the util.py file.
    test = ida_lib.connect_to_ida(b"5945", pid.encode())

    # Open a saved building
    building = call_ida_api_function(ida_lib.openDocument, model)
    
    # Getting name of building
    name = ida_get_name(building)
    print("Opening case: " + name)
    
    print("Saving results to file...")
    # Retreiving results
    origos = get_origo(building)
    # Writing results to file
    # sim_results.to_csv('C:\\Temp\\sim_results.csv', index = False)

    # Disconnect
    #close = call_ida_api_function(ida_lib.exitSession)
    end = ida_lib.ida_disconnect()
    print("Finished")
    return origos
    
def write_geometry(path_h5, origos):
    # Initializing geometry dataframe and reading measuring plane names
    geometry = pd.DataFrame() 
    geometry['x'] = np.nan
    geometry['y'] = np.nan
    geometry['z'] = np.nan
    geometry['ICEName'] = np.nan
    geometry['ICEZone'] = np.nan 
    h5f = h5py.File(path_h5, 'r')
    planes = list(h5f.keys())
   
    for p in planes:
        origo = origos[origos['Zone_name'] == p]
        for k in h5f[p + '/Z']:
            for j in h5f[p + '/Y']:
                for i in h5f[p + '/X']:
                    cur = {'ICEZone' : [p], 
                           'ICEName' : ['{}_{}_{}_{}'.format(p, i, j, k)], 
                           'x' : [i + float(origo['Origo_x'].iloc[0])], 
                           'y' : [j + float(origo['Origo_y'].iloc[0])], 
                           'z' : [k + float(origo['Origo_z'].iloc[0])]}
                    geometry = pd.concat([geometry, 
                                          pd.DataFrame.from_dict(cur)])
    h5f.close()                
    return geometry
    
def write_results(path_h5, path_csv, year):
    reg_keys = ['Id', 'X', 'Y', 'Z', 'time']
    df = pd.DataFrame()
    df_agg = pd.DataFrame()
 
    h5f = h5py.File(path_h5, 'r')
    planes = list(h5f.keys())
    calc_vars = set(reg_keys) ^ set(h5f[planes[0]].keys()) #All planes are assumed to have the same variables logged
    
    
    for cv in calc_vars:     
        for p in planes:
            print(p)
            try:
                res = np.array(h5f[p + '/' + cv + '/data'])
            except:
                continue
            X = h5f[p + '/X']
            Y = h5f[p + '/Y']
            Z = h5f[p + '/Z']
            if p == planes[0]:
                time = list(h5f[p + '/time/data'])
                df['Datetime'] = pd.to_datetime(time, origin = pd.Timestamp(str(year) + '-01-01'), unit = 's')
            else:
                pass
                
            for z in range(len(Z)):
                for y in range(len(Y)):
                    for x in range(len(X)):
                        cur_agg = pd.DataFrame()
                        cur = pd.DataFrame()
                        cur['{}_{}_{}_{}'.format(p, X[x], Y[y], Z[z])] = res[z, y, x, :]
                        df = pd.concat([df, cur], axis = 1)
                        
                        
                        if cv == "Illum":                            
                            udi_tot = round(len(res[z, y, x, :][(res[z, y, x, :] >= 300) & (res[z, y, x, :] <= 3000)])/res[z, y, x, :].shape[0], 2) 
                            
                            cur_udi = pd.DataFrame()
                            cur_udi['Datetime'] = pd.to_datetime(time, origin = pd.Timestamp(str(year) + '-01-01'), unit = 's')
                            cur_udi['ill'] = res[z, y, x, :]
                            cur_udi = cur_udi.set_index('Datetime')
                            cur_udi['Hour'] = cur_udi.index.hour
                            cur_udi['Day'] = cur_udi.index.weekday
                            cur_udi = cur_udi[(cur_udi['Hour'] >= 8) & (cur_udi['Hour'] < 18)]
                            udi_sub = round(len(cur_udi[(cur_udi['ill'] >= 300) & (cur_udi['ill'] <= 3000)])/cur_udi.shape[0], 2)
                            

                            cur_agg = pd.concat([cur_agg, pd.DataFrame.from_dict({'ICEName' : ['{}_{}_{}_{}'.format(p, X[x], Y[y], Z[z])], 
                                                                                  'UDI_tot' : udi_tot,
                                                                                  'UDI_sub' : udi_sub})], 
                                                axis = 0)
                        else:
                         pass
                        
                        df_agg = pd.concat([df_agg, cur_agg], axis = 0)

        df.to_csv(path_csv + cv + '.csv',
                  index = False,
                  encoding = 'utf-8',
                  decimal = '.',
                  na_rep = 'NaN')
        
        df_agg.to_csv(path_csv + 'aggregated' + '.csv',
                          index = False,
                          encoding = 'utf-8',
                          decimal = '.',
                          na_rep = 'NaN')   
    h5f.close()                
    return None

    
def main():
    model = b"C:\\Temp\\test.idm"
    origos = get_origo_zones(model)
    #print(origos)
    path_ggzone = "C:\\Temp\\test\\energy\\FIELD-3D.h5"
    geometry = write_geometry(path_ggzone, origos)
    geometry.to_csv("C:\\Temp\\geometry.csv", 
                    index = False,
                    encoding = 'utf-8',
                    decimal = '.',
                    na_rep = 'NaN')
    path_csv = "C:\\Temp\\"
    year = 2023
    write_results(path_h5 = path_ggzone, path_csv = path_csv, year = year)
    
if __name__ == "__main__":
    main()

